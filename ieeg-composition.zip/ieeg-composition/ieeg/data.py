"""Cohort construction, label parsing and recording loading.

The two adult releases annotate channels differently:

    ds003876  separate `soz`, `epz` and `rz` columns, values 'yes' or absent
    ds004100  comma-separated tags inside `status_description`

Both are normalised to boolean masks here. Three details in this module were
each necessary to get the data to load or to load correctly, and are documented
where they occur: interictal preference, channel-name reconciliation with a
uniqueness constraint, and BrainVision support for the intraoperative release.
"""
from __future__ import annotations

import glob
import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C


# ─────────────────────────────────────────────────────────────────
# labels
# ─────────────────────────────────────────────────────────────────
def parse_labels(ch: pd.DataFrame) -> dict:
    """Return {'rz', 'soz', 'epz'} boolean Series for either annotation format."""
    false = pd.Series(False, index=ch.index)

    if "rz" in ch.columns or "soz" in ch.columns:          # ds003876
        def col(name):
            if name not in ch.columns:
                return false.copy()
            return ch[name].astype(str).str.strip().str.lower().eq("yes")
        return {"rz": col("rz"), "soz": col("soz"), "epz": col("epz")}

    if "status_description" in ch.columns:                 # ds004100
        sd = ch["status_description"].fillna("").astype(str).str.lower()
        return {
            "rz": sd.str.contains("resect") | sd.str.contains("ablat"),
            "soz": sd.str.contains("soz"),
            "epz": false.copy(),
        }

    return {"rz": false.copy(), "soz": false.copy(), "epz": false.copy()}


def valid_mask(ch: pd.DataFrame) -> pd.Series:
    """Channels that are marked good and are not scalp EEG or EKG.

    ds004100 recordings begin with scalp and EKG channels. Retaining them
    inflates the apparent bad-channel fraction and distorts prevalence, so they
    are removed by name before anything else.
    """
    good = (ch["status"].astype(str).str.lower().eq("good")
            if "status" in ch.columns else pd.Series(True, index=ch.index))
    scalp = ch["name"].astype(str).str.upper().str.match(C.SCALP_PATTERN, na=False)
    return good & ~scalp


# ─────────────────────────────────────────────────────────────────
# cohort
# ─────────────────────────────────────────────────────────────────
def _channels_files(ds_dir: Path):
    return sorted(glob.glob(str(ds_dir / "**" / "*channels.tsv"), recursive=True))


def build_cohort(dataset: str) -> pd.DataFrame:
    ds_dir = C.DATASETS[dataset]
    files = _channels_files(ds_dir)
    if not files:
        raise FileNotFoundError(f"No channels.tsv under {ds_dir}")

    # Prefer interictal recordings. ds004100 ships both ictal and interictal
    # runs; this study is about interictal data, and without this filter the
    # ictal runs are selected for most participants.
    inter = [f for f in files if "task-interictal" in f]
    if inter:
        keep = {re.search(r"sub-([A-Za-z0-9]+)", f).group(1) for f in inter}
        files = inter + [f for f in files
                         if re.search(r"sub-([A-Za-z0-9]+)", f).group(1) not in keep]

    rows, seen = [], set()
    for f in files:
        m = re.search(r"sub-([A-Za-z0-9]+)", f)
        if not m:
            continue
        sub = f"sub-{m.group(1)}"
        if sub in seen:
            continue
        seen.add(sub)

        ch = pd.read_csv(f, sep="\t")
        lab = parse_labels(ch)
        v = valid_mask(ch)
        n_valid = int(v.sum())
        rz = int((lab["rz"] & v).sum())

        rows.append({
            "dataset": dataset, "sub": sub, "channels_tsv": f,
            "n_ch": len(ch), "n_valid": n_valid,
            "rz": rz,
            "soz": int((lab["soz"] & v).sum()),
            "epz": int((lab["epz"] & v).sum()),
            "prevalence": rz / n_valid if n_valid else np.nan,
            "sfreq": (float(ch["sampling_frequency"].iloc[0])
                      if "sampling_frequency" in ch.columns else np.nan),
            "ch_type": (ch.loc[v, "type"].mode().iloc[0]
                        if "type" in ch.columns and n_valid else "UNKNOWN"),
        })

    coh = pd.DataFrame(rows)
    part = _participants(ds_dir)
    if part is not None:
        coh = coh.merge(part, on="sub", how="left")
    return _harmonise(coh, dataset)


def _participants(ds_dir: Path):
    p = ds_dir / "participants.tsv"
    if not p.exists():
        return None
    df = pd.read_csv(p, sep="\t")
    df.columns = [c.strip() for c in df.columns]
    df["sub"] = df[df.columns[0]].astype(str).str.strip()   # HUP151 has a
    return df.drop_duplicates("sub")                         # trailing space


def _harmonise(coh: pd.DataFrame, dataset: str) -> pd.DataFrame:
    """Bring the two releases onto common column names and definitions."""
    if "engel" in coh.columns:                    # ds004100: '1A', '2C', ...
        coh["engel_num"] = pd.to_numeric(
            coh["engel"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    elif "engel_score" in coh.columns:            # ds003876: numeric
        coh["engel_num"] = pd.to_numeric(coh["engel_score"], errors="coerce")
    else:
        coh["engel_num"] = np.nan

    coh["seizure_free"] = coh["engel_num"].eq(1)

    if "therapy" in coh.columns:
        coh["therapy"] = coh["therapy"].astype(str).str.upper().str.strip()
    else:
        coh["therapy"] = np.where(coh["rz"] > 0, "RESECTION", "NONE")

    if "implant" in coh.columns:
        coh["implant"] = coh["implant"].astype(str).str.upper().str.strip()
    else:
        coh["implant"] = coh["ch_type"].astype(str).str.upper()

    coh["usable"] = (coh["rz"] >= C.MIN_POSITIVE) & coh["engel_num"].notna()
    return coh


def build_all(datasets=("ds003876", "ds004100")) -> pd.DataFrame:
    out = []
    for d in datasets:
        try:
            out.append(build_cohort(d))
        except FileNotFoundError as e:
            warnings.warn(str(e))
    if not out:
        raise RuntimeError("No cohorts built - check the raw data paths")
    keep = ["dataset", "sub", "channels_tsv", "n_ch", "n_valid", "rz", "soz",
            "epz", "prevalence", "sfreq", "engel_num", "seizure_free",
            "therapy", "implant", "usable"]
    coh = pd.concat(out, ignore_index=True)
    for k in keep:
        if k not in coh.columns:
            coh[k] = np.nan
    return coh[keep]


# ─────────────────────────────────────────────────────────────────
# loading
# ─────────────────────────────────────────────────────────────────
def load_recording(row: pd.Series):
    """Load the signal file beside a channels.tsv and align it to the labels.

    Returns (raw, channel_names, sampling_frequency, labels).
    """
    import mne
    from ._namefix import norm, build_map

    ch_path = Path(row["channels_tsv"])
    stem = ch_path.name.replace("_channels.tsv", "")

    # ds003844 is BrainVision, the adult releases are EDF
    cands = []
    for ext in ("edf", "EDF", "vhdr", "VHDR"):
        cands += list(ch_path.parent.glob(f"{stem}*.{ext}"))
    if not cands:
        for ext in ("edf", "vhdr"):
            cands += sorted(ch_path.parent.glob(f"*.{ext}"))
    if not cands:
        raise FileNotFoundError(f"No EDF or BrainVision file beside {ch_path}")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if str(cands[0]).lower().endswith(".vhdr"):
            raw = mne.io.read_raw_brainvision(cands[0], preload=True,
                                              verbose="ERROR")
        else:
            raw = mne.io.read_raw_edf(cands[0], preload=True, verbose="ERROR")

    ch = pd.read_csv(ch_path, sep="\t")
    lab = parse_labels(ch)
    v = valid_mask(ch)

    # Match tsv names to header names through the normalised form. The
    # `not in present` guard matters: without it two tsv channels can map to
    # the same header channel, and MNE raises 'sel is not unique'.
    edf_map = build_map(raw.ch_names)
    wanted_idx, present = [], []
    for i in ch.index[v]:
        key = norm(ch.loc[i, "name"])
        if key in edf_map and edf_map[key] not in present:
            wanted_idx.append(i)
            present.append(edf_map[key])

    if len(present) < 8:
        raise ValueError(
            f"{row['sub']}: only {len(present)} channels matched. "
            f"tsv e.g. {ch.loc[v, 'name'].head(3).tolist()} | "
            f"header e.g. {raw.ch_names[:3]}")

    raw.pick(present)
    labels = {k: lab[k].loc[wanted_idx].to_numpy() for k in ("rz", "soz", "epz")}
    return raw, present, float(raw.info["sfreq"]), labels
