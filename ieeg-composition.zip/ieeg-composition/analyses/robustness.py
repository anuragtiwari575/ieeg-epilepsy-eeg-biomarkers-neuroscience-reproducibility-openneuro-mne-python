"""
Pre-submission robustness analyses addressing anticipated reviewer concerns.

R3  ORIENTATION LEAK (most important)
    Feature sign was resolved from the pooled point-biserial correlation using
    the same labels on which performance is evaluated. Here we recompute every
    metric with LEAVE-ONE-PATIENT-OUT orientation: each participant's sign is
    determined from the other 76 participants only. If conclusions are
    unchanged, the orientation step is not driving the result.

R2  NULL CALIBRATION
    Permutation distribution of lambda with 95% CI, plus a patient-level
    bootstrap CI for the median lambda.

R4  MODEL-CHOICE SENSITIVITY
    The composition-only prediction repeated with ridge regression, ordinary
    least squares and a gradient-boosted tree, plus permutation importance,
    to show the conclusion does not depend on the random forest.

R5  LEAVE-ONE-DATASET-OUT
    Two centres have n = 2, so those folds are uninformative. Cross-cohort
    generalisation is tested at the dataset level instead.
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.metrics import r2_score, average_precision_score
from sklearn.inspection import permutation_importance

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
FEAT = os.path.join(BASE, "features")
rng = np.random.default_rng(0)

coh = pd.read_csv(os.path.join(R, "cohort.csv"))
perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))

part = []
for ds in ["ds003876", "ds004100"]:
    p = pd.read_csv(os.path.join(BASE, "raw", ds, "participants.tsv"), sep="\t")
    p.columns = [c.strip() for c in p.columns]
    p["sub"] = p[p.columns[0]].astype(str).str.strip()
    p["dataset"] = ds
    part.append(p)
part = pd.concat(part, ignore_index=True)
u = coh[coh.usable].merge(part, on=["sub", "dataset"], how="left", suffixes=("", "_p"))
u["centre"] = u["site"].fillna("HUP") if "site" in u else u["dataset"]
u["lesional"] = (u.get("lesion_status", pd.Series(index=u.index, dtype=object))
                 .astype(str).str.upper().eq("LESIONAL").astype(float))
u["is_temporal"] = (u.get("target", pd.Series(index=u.index, dtype=object))
                    .astype(str).str.upper().isin(["TEMPORAL", "MTL"]).astype(float))


# ══════════════════════════════════════════════════════════════════
# R3.  LEAVE-ONE-PATIENT-OUT ORIENTATION
# ══════════════════════════════════════════════════════════════════
print("=" * 72)
print("R3.  ORIENTATION SENSITIVITY  (leave-one-patient-out sign)")
print("=" * 72)

import glob
frames = [pd.read_parquet(f) for f in sorted(glob.glob(os.path.join(FEAT, "*.parquet")))]
allf = pd.concat(frames, ignore_index=True)
feat_cols = [c for c in allf.columns if "::" in c]


def empirical_null_ap(y, n_perm=200, seed=0):
    y = np.asarray(y).astype(bool)
    if y.sum() < 1 or y.all():
        return np.nan
    g = np.random.default_rng(seed)
    return float(np.mean([average_precision_score(y, g.random(len(y)))
                          for _ in range(n_perm)]))


rows = []
for fc in feat_cols:
    pat = []
    for (ds, sub), g in allf.groupby(["dataset", "sub"]):
        y = g["rz"].to_numpy().astype(bool)
        if y.sum() < 2 or y.all():
            continue
        pat.append({"sub": sub, "score": g[fc].to_numpy(float), "y": y})
    if len(pat) < 10:
        continue

    # per-patient point-biserial contribution
    stat = []
    for p_ in pat:
        ok = np.isfinite(p_["score"])
        if ok.sum() > 5 and len(np.unique(p_["y"][ok])) > 1:
            r_, _ = stats.pointbiserialr(p_["y"][ok].astype(float), p_["score"][ok])
            stat.append(r_ if np.isfinite(r_) else 0.0)
        else:
            stat.append(0.0)
    stat = np.array(stat)

    for i, p_ in enumerate(pat):
        loo_sign = 1.0 if np.nanmean(np.delete(stat, i)) >= 0 else -1.0
        pooled_sign = 1.0 if np.nanmean(stat) >= 0 else -1.0
        null = empirical_null_ap(p_["y"])
        rows.append({
            "feature": fc, "sub": p_["sub"],
            "lift_loo": average_precision_score(p_["y"], loo_sign * p_["score"]) / null,
            "lift_pooled": average_precision_score(p_["y"], pooled_sign * p_["score"]) / null,
            "sign_flipped": loo_sign != pooled_sign,
        })

O = pd.DataFrame(rows)
O.to_csv(os.path.join(R, "TABLE_orientation_sensitivity.csv"), index=False)

flip = O.sign_flipped.mean()
agg = O.groupby("feature")[["lift_pooled", "lift_loo"]].mean()
r_, p_ = stats.pearsonr(agg.lift_pooled, agg.lift_loo)
print(f"patient-feature pairs where the sign flipped : {100*flip:.1f}%")
print(f"mean lift, pooled orientation                : {agg.lift_pooled.mean():.3f}")
print(f"mean lift, leave-one-patient-out orientation : {agg.lift_loo.mean():.3f}")
print(f"correlation between the two                  : r = {r_:.3f}")

meta = u.set_index("sub")[["seizure_free", "therapy"]]
res = []
for feat, g in O.groupby("feature"):
    g = g.join(meta, on="sub")
    g = g[g.therapy == "RESECTION"]
    a = g.loc[g.seizure_free == True, "lift_loo"]
    b = g.loc[g.seizure_free == False, "lift_loo"]
    if len(a) < 5 or len(b) < 5:
        continue
    res.append(stats.mannwhitneyu(a, b).pvalue)
print(f"\nOutcome test under LOO orientation (resection stratum):")
print(f"  features with p < 0.05 : {sum(p < .05 for p in res)} of {len(res)}")
print("  -> conclusion unchanged if this is 0")


# ══════════════════════════════════════════════════════════════════
# R2.  NULL CALIBRATION
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 72)
print("R2.  CALIBRATION OF THE EMPIRICAL NULL")
print("=" * 72)

ctrl = pd.read_csv(os.path.join(R, "permutation_controls.csv"))
print(f"permuted mean lambda      : {ctrl.perm_mean_lift.mean():.4f}")
print(f"across features, 95% range: [{ctrl.perm_ci_lo.min():.3f}, "
      f"{ctrl.perm_ci_hi.max():.3f}]")

boot = []
for feat, g in perf.groupby("feature"):
    v = g.lift_emp.dropna().to_numpy()
    if len(v) < 20:
        continue
    meds = [np.median(rng.choice(v, len(v), replace=True)) for _ in range(2000)]
    boot.append({"feature": feat, "median": np.median(v),
                 "ci_lo": np.percentile(meds, 2.5),
                 "ci_hi": np.percentile(meds, 97.5)})
Bt = pd.DataFrame(boot).sort_values("median", ascending=False)
Bt.round(3).to_csv(os.path.join(R, "TABLE_lift_bootstrap_ci.csv"), index=False)
print(f"\nfeatures whose bootstrap CI for median lambda excludes 1: "
      f"{(Bt.ci_lo > 1).sum()} of {len(Bt)}")
print(Bt.round(3).head(8).to_string(index=False))


# ══════════════════════════════════════════════════════════════════
# R4.  MODEL-CHOICE SENSITIVITY
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 72)
print("R4.  DOES THE COMPOSITION RESULT DEPEND ON THE RANDOM FOREST?")
print("=" * 72)

D = perf.merge(u[["sub", "centre", "therapy", "implant", "lesional",
                  "is_temporal", "n_valid"]], on="sub", how="left")
COMP = ["prevalence", "is_resection", "is_ecog", "lesional", "is_temporal", "n_valid"]
MODELS = {
    "random forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                                           random_state=0, n_jobs=-1),
    "gradient boost": GradientBoostingRegressor(random_state=0),
    "ridge": Ridge(alpha=1.0),
    "linear": LinearRegression(),
}

out = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "lift_emp", "prevalence"]).copy()
    if len(g) < 30:
        continue
    g["is_resection"] = (g.therapy == "RESECTION").astype(float)
    g["is_ecog"] = (g.implant == "ECOG").astype(float)
    X = g[COMP].fillna(0).to_numpy()
    grp = g.centre.fillna("NA").to_numpy()
    cv = GroupKFold(n_splits=min(4, len(np.unique(grp))))
    row = {"feature": feat}
    for name, m in MODELS.items():
        for tgt in ["auprc", "lift_emp"]:
            y = g[tgt].to_numpy()
            try:
                pred = cross_val_predict(m, X, y, cv=cv, groups=grp)
            except Exception:
                pred = cross_val_predict(m, X, y, cv=4)
            row[f"{name}|{tgt}"] = r2_score(y, pred)
    out.append(row)

M = pd.DataFrame(out)
M.round(3).to_csv(os.path.join(R, "TABLE_model_sensitivity.csv"), index=False)
print("\nMedian cross-validated R^2 across 28 features:\n")
summ = pd.DataFrame({
    "predicting AP": [M[f"{n}|auprc"].median() for n in MODELS],
    "predicting lift": [M[f"{n}|lift_emp"].median() for n in MODELS],
    "features AP R2>0.3": [(M[f"{n}|auprc"] > .3).sum() for n in MODELS],
    "features lift R2>0.3": [(M[f"{n}|lift_emp"] > .3).sum() for n in MODELS],
}, index=list(MODELS))
print(summ.round(3).to_string())

# permutation importance on the best-predicted feature
best = M.set_index("feature")["random forest|auprc"].idxmax()
g = D[D.feature == best].dropna(subset=["auprc", "prevalence"]).copy()
g["is_resection"] = (g.therapy == "RESECTION").astype(float)
g["is_ecog"] = (g.implant == "ECOG").astype(float)
rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                           random_state=0, n_jobs=-1).fit(
    g[COMP].fillna(0), g.auprc)
imp = permutation_importance(rf, g[COMP].fillna(0), g.auprc,
                             n_repeats=50, random_state=0)
print(f"\nPermutation importance for {best}:")
for n, m_, s_ in sorted(zip(COMP, imp.importances_mean, imp.importances_std),
                        key=lambda x: -x[1]):
    print(f"  {n:15s} {m_:+.3f} ± {s_:.3f}")


# ══════════════════════════════════════════════════════════════════
# R5.  LEAVE-ONE-DATASET-OUT
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 72)
print("R5.  LEAVE-ONE-DATASET-OUT  (two centres have n = 2)")
print("=" * 72)

rows = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "prevalence"]).copy()
    if len(g) < 30:
        continue
    g["is_resection"] = (g.therapy == "RESECTION").astype(float)
    g["is_ecog"] = (g.implant == "ECOG").astype(float)
    X = g[COMP].fillna(0).to_numpy()
    grp = g.dataset.to_numpy() if "dataset" in g else np.array(["a"] * len(g))
    if len(np.unique(grp)) < 2:
        continue
    m = RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                              random_state=0, n_jobs=-1)
    pred = cross_val_predict(m, X, g.auprc.to_numpy(),
                             cv=GroupKFold(n_splits=2), groups=grp)
    rows.append({"feature": feat, "R2_lodo": r2_score(g.auprc, pred)})

if rows:
    L = pd.DataFrame(rows)
    L.round(3).to_csv(os.path.join(R, "TABLE_leave_one_dataset_out.csv"), index=False)
    print(f"median R^2 (leave-one-dataset-out) : {L.R2_lodo.median():.3f}")
    print(f"features above 0.3                 : {(L.R2_lodo > .3).sum()} of {len(L)}")
else:
    print("dataset column not present in per_patient_metrics.csv")

print("\nAll tables written to", R)
