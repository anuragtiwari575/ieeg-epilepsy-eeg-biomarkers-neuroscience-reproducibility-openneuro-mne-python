"""
Logistic sensitivity analysis for the outcome result.

The main analysis adjusts for prevalence, treatment and implant modality by
partial correlation on ordinary least-squares residuals. Seizure freedom is
binary, so logistic regression is the more natural model and a reviewer will
reasonably ask for it. This fits, for each feature,

    logit P(Engel I) = b0 + b1*lambda + b2*prevalence
                          + b3*is_resection + b4*is_ecog

and reports the coefficient on lambda with its confidence interval, with
Benjamini-Hochberg correction across the 28 features. It also fits the same
model within the resection stratum alone, which is the paper's primary
presentation, and reports the minimum detectable effect at 80% power.
"""
import os
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")

perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))
coh = pd.read_csv(os.path.join(R, "cohort.csv"))
u = coh[coh.usable].copy()
u["is_resection"] = (u.therapy == "RESECTION").astype(float)
u["is_ecog"] = (u.implant == "ECOG").astype(float)
u["free"] = u.seizure_free.astype(int)

D = perf.merge(u[["sub", "is_resection", "is_ecog", "free", "therapy"]],
               on="sub", how="inner")

COV = ["lift_emp", "prevalence", "is_resection", "is_ecog"]


def fit(df, cols, label):
    out = []
    for feat, g in df.groupby("feature"):
        g = g.dropna(subset=cols + ["free"])
        if len(g) < 25 or g.free.nunique() < 2:
            continue
        X = sm.add_constant(g[cols].astype(float))
        try:
            m = sm.Logit(g.free, X).fit(disp=0, maxiter=200)
        except Exception:
            continue
        if "lift_emp" not in m.params:
            continue
        b, se = m.params["lift_emp"], m.bse["lift_emp"]
        out.append({"feature": feat, "n": len(g), "beta": b, "se": se,
                    "OR": np.exp(b), "ci_lo": np.exp(b - 1.96 * se),
                    "ci_hi": np.exp(b + 1.96 * se), "p": m.pvalues["lift_emp"]})
    A = pd.DataFrame(out)
    if len(A):
        A["q_BH"] = multipletests(A.p, method="fdr_bh")[1]
        A = A.sort_values("p")
    print("\n" + "=" * 74)
    print(label)
    print("=" * 74)
    if not len(A):
        print("  insufficient data"); return A
    print(f"{'feature':<26}{'n':>5}{'OR per unit lift':>18}{'95% CI':>18}"
          f"{'p':>9}{'q':>9}")
    for _, r in A.head(10).iterrows():
        print(f"{r.feature:<26}{int(r.n):5d}{r.OR:18.3f}"
              f"{f'{r.ci_lo:.2f}-{r.ci_hi:.2f}':>18}{r.p:9.4f}{r.q_BH:9.4f}")
    print(f"\nfeatures with p < 0.05 : {(A.p < .05).sum()} of {len(A)}")
    print(f"features with q < 0.05 : {(A.q_BH < .05).sum()} of {len(A)}")
    return A


A_all = fit(D, COV, "ALL PARTICIPANTS  (n = 77)")
A_all.round(4).to_csv(os.path.join(R, "TABLE_logistic_outcome_all.csv"),
                      index=False)

res = D[D.therapy == "RESECTION"]
A_res = fit(res, ["lift_emp", "prevalence", "is_ecog"],
            "RESECTION STRATUM  (therapy constant, so dropped as a covariate)")
A_res.round(4).to_csv(os.path.join(R, "TABLE_logistic_outcome_resection.csv"),
                      index=False)

# ── minimum detectable effect ─────────────────────────────────────
print("\n" + "=" * 74)
print("POWER")
print("=" * 74)
sub = u.drop_duplicates("sub")
r = sub[sub.therapy == "RESECTION"]
n1, n2 = int(r.free.sum()), int((1 - r.free).sum())
za, zb = stats.norm.ppf(0.975), stats.norm.ppf(0.80)
d = (za + zb) * np.sqrt(1 / n1 + 1 / n2)
print(f"resection stratum: {n1} seizure-free vs {n2} failed")
print(f"minimum standardised difference detectable at 80% power: d = {d:.2f}")
print(f"  (a two-sided test at alpha = 0.05)")

n1a, n2a = int(sub.free.sum()), int((1 - sub.free).sum())
da = (za + zb) * np.sqrt(1 / n1a + 1 / n2a)
print(f"\nwhole cohort: {n1a} vs {n2a}, d = {da:.2f}")

print("\nINTERPRETATION")
print("  If the logistic models agree with the partial correlations -- no")
print("  feature significant after correction -- the outcome result does not")
print("  depend on the linear-residual approach, and the power figures state")
print("  what the null does and does not exclude.")
print(f"\ntables written to {R}")
