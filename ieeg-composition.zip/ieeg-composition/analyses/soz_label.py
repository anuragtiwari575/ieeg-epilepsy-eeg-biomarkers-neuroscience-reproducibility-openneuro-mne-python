"""
FIX 2. The seizure onset zone is annotated in both releases and was never used.

Our primary label is the treated volume, a proxy for the epileptogenic zone. The
manuscript defends this at length in Discussion 4.2. But both releases also carry
a clinician-annotated seizure onset zone -- ds003876 in its `soz` column,
ds004100 in the `soz` tag of `status_description` -- and using it turns that
defence from an argument into a comparison.

This repeats the three primary analyses with the SOZ as the positive class:

    1. prevalence confound      corr(AP, prevalence) per feature
    2. localization evidence    which features exceed the empirical null (BH)
    3. spatial specificity      the same under the spatially constrained null

If the confound is the same size against both labels, it is a property of the
metric rather than of the treated-volume proxy. If the five spectral features
behave differently against the SOZ, that is informative either way.
"""
import os
import re
import glob
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score
from statsmodels.stats.multitest import multipletests

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")
FEAT = os.path.join(BASE, "features")
rng = np.random.default_rng(0)
MIN_POS = 2


def shaft_of(name):
    return re.sub(r"\d+$", "", str(name).strip().upper()) or "UNK"


def iid_null(y, n=200, seed=0):
    g = np.random.default_rng(seed)
    return float(np.mean([average_precision_score(y, g.random(len(y)))
                          for _ in range(n)]))


def spatial_null(y, s, shafts, n=300, seed=0):
    g = np.random.default_rng(seed)
    by = {}
    for i, sh in enumerate(shafts):
        by.setdefault(sh, []).append(i)
    by = {k: np.array(v) for k, v in by.items() if len(v) >= 2}
    if not any(0 < y[v].sum() < len(v) for v in by.values()):
        return np.nan
    aps = []
    for _ in range(n):
        yy = y.copy()
        for sh, idx in by.items():
            seg = y[idx]
            if seg.all() or not seg.any():
                continue
            yy[idx] = np.roll(seg, g.integers(1, len(idx)))
        if 0 < yy.sum() < len(yy):
            aps.append(average_precision_score(yy, s))
    return float(np.mean(aps)) if aps else np.nan


files = sorted(glob.glob(os.path.join(FEAT, "*.parquet")))
allf = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
feat_cols = [c for c in allf.columns if "::" in c]

if "soz" not in allf.columns:
    raise SystemExit("no `soz` column in the feature files -- re-run the "
                     "feature stage, which stores rz, soz and epz")

# ── how much SOZ is there? ────────────────────────────────────────
print("=" * 74)
print("SEIZURE ONSET ZONE AS THE POSITIVE CLASS")
print("=" * 74)
d = []
for (ds, sub), g in allf.groupby(["dataset", "sub"]):
    d.append({"dataset": ds, "sub": sub, "n_ch": len(g),
              "n_soz": int(g["soz"].sum()), "n_rz": int(g["rz"].sum()),
              "prev_soz": g["soz"].mean(), "prev_rz": g["rz"].mean(),
              "soz_in_rz": int((g["soz"] & g["rz"]).sum())})
D = pd.DataFrame(d)
ok = D[D.n_soz >= MIN_POS]
print(f"participants with at least {MIN_POS} SOZ channels: {len(ok)} of {len(D)}")
print(f"  by dataset: {ok.groupby('dataset').size().to_dict()}")
print(f"\nSOZ prevalence : median {100*ok.prev_soz.median():.1f}% "
      f"(range {100*ok.prev_soz.min():.1f}-{100*ok.prev_soz.max():.1f}%)")
print(f"treated volume : median {100*ok.prev_rz.median():.1f}% "
      f"(range {100*ok.prev_rz.min():.1f}-{100*ok.prev_rz.max():.1f}%)")
overlap = ok[ok.n_soz > 0]
print(f"\nSOZ channels also within the treated volume: median "
      f"{100*(overlap.soz_in_rz/overlap.n_soz).median():.0f}%")
D.to_csv(os.path.join(R, "TABLE_soz_availability.csv"), index=False)

if len(ok) < 20:
    raise SystemExit("too few participants with SOZ annotation for this analysis")

# ── recompute the primary metrics against the SOZ ─────────────────
rows = []
for k, fc in enumerate(feat_cols, 1):
    pats = []
    for (ds, sub), g in allf.groupby(["dataset", "sub"]):
        y = g["soz"].to_numpy().astype(bool)
        if y.sum() < MIN_POS or y.all():
            continue
        sc = g[fc].to_numpy(float)
        m = np.isfinite(sc)
        if m.sum() < 10:
            continue
        pats.append({"sub": sub, "y": y[m], "s": sc[m],
                     "sh": np.array([shaft_of(c) for c in g["channel"]])[m]})
    if len(pats) < 15:
        continue

    contrib = []
    for p in pats:
        if len(np.unique(p["y"])) > 1:
            r_, _ = stats.pointbiserialr(p["y"].astype(float), p["s"])
            contrib.append(r_ if np.isfinite(r_) else 0.0)
        else:
            contrib.append(0.0)
    contrib = np.asarray(contrib)

    for i, p in enumerate(pats):
        sign = 1.0 if np.nanmean(np.delete(contrib, i)) >= 0 else -1.0
        y, s = p["y"], sign * p["s"]
        ap = average_precision_score(y, s)
        ni = iid_null(y)
        ns = spatial_null(y, s, p["sh"])
        rows.append({"feature": fc, "sub": p["sub"], "prevalence": y.mean(),
                     "auprc": ap,
                     "lift_iid": ap / ni if ni else np.nan,
                     "lift_spatial": ap / ns if ns == ns and ns else np.nan})
    print(f"  [{k}/{len(feat_cols)}] {fc}", flush=True)

P = pd.DataFrame(rows)
P.to_csv(os.path.join(R, "TABLE_soz_metrics.csv"), index=False)

# ── 1. prevalence confound ────────────────────────────────────────
print("\n" + "=" * 74)
print("1.  DOES AVERAGE PRECISION TRACK PREVALENCE AGAINST THE SOZ TOO?")
print("=" * 74)
cs = []
for feat, g in P.groupby("feature"):
    g = g.dropna(subset=["auprc", "prevalence"])
    if len(g) < 15:
        continue
    r_, p_ = stats.pearsonr(g.prevalence, g.auprc)
    cs.append({"feature": feat, "r": r_, "p": p_, "n": len(g)})
C = pd.DataFrame(cs)
C.round(4).to_csv(os.path.join(R, "TABLE_soz_correlation.csv"), index=False)
print(f"corr(AP, prevalence) across {len(C)} features: "
      f"{C.r.min():.2f} to {C.r.max():.2f}, median {C.r.median():.2f}")
print(f"features with p < 0.05: {(C.p < .05).sum()} of {len(C)}")
print("\nAgainst the treated volume the same range was 0.53 to 0.88.")
print("A comparable range means the confound is a property of the metric")
print("rather than of the treated-volume proxy.")

# ── 2 and 3. localization evidence under each null ────────────────
def evid(col):
    out = []
    for feat, g in P.groupby("feature"):
        v = g[col].dropna().to_numpy()
        if len(v) < 15:
            continue
        meds = np.array([np.median(rng.choice(v, len(v), replace=True))
                         for _ in range(5000)])
        out.append({"feature": feat, "n": len(v), "median": float(np.median(v)),
                    "ci_lo": float(np.percentile(meds, 2.5)),
                    "ci_hi": float(np.percentile(meds, 97.5)),
                    "p_boot": float(np.mean(meds <= 1.0))})
    A = pd.DataFrame(out)
    A["q_BH"] = multipletests(A.p_boot.clip(lower=1 / 5000), method="fdr_bh")[1]
    return A.sort_values("median", ascending=False)


I, S = evid("lift_iid"), evid("lift_spatial")
I.round(4).to_csv(os.path.join(R, "TABLE_soz_evidence_iid.csv"), index=False)
S.round(4).to_csv(os.path.join(R, "TABLE_soz_evidence_spatial.csv"), index=False)

si = set(I.loc[(I.q_BH < .05) & (I["median"] > 1), "feature"])
ss = set(S.loc[(S.q_BH < .05) & (S["median"] > 1), "feature"])

print("\n" + "=" * 74)
print("2 & 3.  WHICH FEATURES EXCEED EACH NULL, AGAINST THE SOZ")
print("=" * 74)
print(f"i.i.d. null       : {len(si)} of {len(I)} features")
print(f"spatial-shift null: {len(ss)} of {len(S)} features\n")
print(f"{'feature':<26}{'lift iid':>10}{'q iid':>9}{'lift spa':>10}{'q spa':>9}")
for f_ in sorted(si | ss, key=lambda x: -I.set_index("feature").loc[x, "median"]):
    ri = I.set_index("feature").loc[f_]
    rs = S.set_index("feature").loc[f_] if f_ in set(S.feature) else None
    print(f"{f_:<26}{ri['median']:10.2f}{ri.q_BH:9.4f}"
          f"{(rs['median'] if rs is not None else np.nan):10.2f}"
          f"{(rs.q_BH if rs is not None else np.nan):9.4f}")

FIVE = {"spectral::rel_delta", "spectral::bp_delta", "spectral::bp_theta",
        "spectral::rel_alpha", "spectral::spec_entropy"}
print(f"\nof the five features surviving against the treated volume, "
      f"{len(FIVE & si)} also survive against the SOZ under the i.i.d. null")
print(f"and {len(FIVE & ss)} under the spatial null")
if si - FIVE:
    print(f"features surviving against the SOZ but not the treated volume: "
          f"{sorted(si - FIVE)}")

print(f"\ntables written to {R}")
