"""
A2. Does the empirical null give credit for spatial smoothness alone?

THE CONCERN
    The empirical null draws i.i.d. uniform scores. Real biomarker scores are
    not i.i.d.: neighbouring contacts on the same electrode are correlated, and
    the treated volume is itself spatially contiguous. A score that is merely a
    smooth spatial gradient -- carrying no information about epileptogenicity --
    can therefore beat an i.i.d. null.

    This matters because all five features that survived correction are
    low-frequency spectral measures (delta, theta, alpha power and spectral
    entropy). Focal slowing is a marker of structural lesion, not specifically
    of epileptogenicity, and lesions are spatially contiguous. The five
    survivors may be detecting the lesion rather than the epileptogenic zone.

THE TEST
    Replace the i.i.d. null with a SPATIALLY CONSTRAINED one. Keep each
    participant's score vector exactly as observed, and instead randomise the
    position of the treated-volume label while preserving its spatial
    structure: within each electrode shaft, circularly shift that shaft's label
    segment by a random offset. This preserves the number of treated channels
    per shaft and their contiguity, and asks a sharper question -- does the
    biomarker point at THIS treated volume, or merely at somewhere smooth?

        lambda_spatial = AP(y, s) / mean_b AP(shift_b(y), s)

    A feature that survives the i.i.d. null but not the spatial null is
    detecting spatial structure rather than the specific treated region.

    We additionally test the lesional interpretation directly: is lambda higher
    in participants with an MRI-visible lesion?
"""
import os
import re
import glob
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score
from statsmodels.stats.multitest import multipletests

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")
FEAT = os.path.join(BASE, "features")
rng = np.random.default_rng(0)
B_SPATIAL, B_IID = 300, 200


def shaft_of(name: str) -> str:
    """Electrode identifier: the name with its trailing contact number removed."""
    return re.sub(r"\d+$", "", str(name).strip().upper()) or "UNK"


def spatial_null_ap(y, s, shafts, n_draw=B_SPATIAL, seed=0):
    """Mean AP when the label pattern is circularly shifted within each shaft.

    Preserves the per-shaft positive count and the contiguity of the treated
    segment, so the null retains the spatial structure of a real resection.
    """
    g = np.random.default_rng(seed)
    idx_by_shaft = {}
    for i, sh in enumerate(shafts):
        idx_by_shaft.setdefault(sh, []).append(i)
    idx_by_shaft = {k: np.array(v) for k, v in idx_by_shaft.items()
                    if len(v) >= 2}
    if not idx_by_shaft:
        return np.nan, 0

    movable = sum(1 for k, v in idx_by_shaft.items()
                  if 0 < y[v].sum() < len(v))
    if movable == 0:
        return np.nan, 0

    aps = []
    for _ in range(n_draw):
        yy = y.copy()
        for sh, idx in idx_by_shaft.items():
            seg = y[idx]
            if seg.all() or not seg.any():
                continue
            yy[idx] = np.roll(seg, g.integers(1, len(idx)))
        if yy.sum() == 0 or yy.all():
            continue
        aps.append(average_precision_score(yy, s))
    return (float(np.mean(aps)) if aps else np.nan), movable


def iid_null_ap(y, n_draw=B_IID, seed=0):
    g = np.random.default_rng(seed)
    return float(np.mean([average_precision_score(y, g.random(len(y)))
                          for _ in range(n_draw)]))


files = sorted(glob.glob(os.path.join(FEAT, "*.parquet")))
allf = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
feat_cols = [c for c in allf.columns if "::" in c]
print(f"{len(files)} participants, {len(feat_cols)} features\n")

# ── how much spatial freedom is there at all? ─────────────────────
diag = []
for (ds, sub), g in allf.groupby(["dataset", "sub"]):
    y = g["rz"].to_numpy().astype(bool)
    sh = np.array([shaft_of(c) for c in g["channel"]])
    n_sh = len(set(sh))
    mixed = sum(1 for s_ in set(sh)
                if 0 < y[sh == s_].sum() < (sh == s_).sum())
    diag.append({"sub": sub, "n_channels": len(y), "n_shafts": n_sh,
                 "shafts_partially_treated": mixed,
                 "prevalence": y.mean()})
D = pd.DataFrame(diag)
print("Spatial freedom available for the shift null:")
print(f"  shafts per participant           : median {D.n_shafts.median():.0f} "
      f"(range {D.n_shafts.min()}-{D.n_shafts.max()})")
print(f"  partially treated shafts          : median "
      f"{D.shafts_partially_treated.median():.0f}")
print(f"  participants with none (excluded)  : "
      f"{(D.shafts_partially_treated == 0).sum()} of {len(D)}\n")

# ── recompute lift under both nulls ───────────────────────────────
rows = []
for k, fc in enumerate(feat_cols, 1):
    # ── assemble the participants for this feature ────────────────
    pats = []
    for (ds, sub), g in allf.groupby(["dataset", "sub"]):
        y = g["rz"].to_numpy().astype(bool)
        if y.sum() < 2 or y.all():
            continue
        sc = g[fc].to_numpy(float)
        ok = np.isfinite(sc)
        if ok.sum() < 10:
            continue
        pats.append({"sub": sub, "y": y[ok], "s": sc[ok],
                     "sh": np.array([shaft_of(c) for c in g["channel"]])[ok]})
    if len(pats) < 10:
        continue

    # ── orientation, leave-one-participant-out ───────────────────
    # Each participant's sign comes from the other participants only. Using
    # a participant's own labels to orient the feature they are then scored
    # against is precisely the leakage this paper argues against, and it
    # inflates every feature above any null.
    contrib = []
    for p_ in pats:
        if len(np.unique(p_["y"])) > 1:
            r_, _ = stats.pointbiserialr(p_["y"].astype(float), p_["s"])
            contrib.append(r_ if np.isfinite(r_) else 0.0)
        else:
            contrib.append(0.0)
    contrib = np.asarray(contrib)

    for i, p_ in enumerate(pats):
        y, sh = p_["y"], p_["sh"]
        sign = 1.0 if np.nanmean(np.delete(contrib, i)) >= 0 else -1.0
        s = sign * p_["s"]
        sub = p_["sub"]

        ap = average_precision_score(y, s)
        n_iid = iid_null_ap(y)
        n_spa, movable = spatial_null_ap(y, s, sh)
        rows.append({"feature": fc, "sub": sub, "prevalence": y.mean(),
                     "auprc": ap,
                     "lift_iid": ap / n_iid if n_iid else np.nan,
                     "lift_spatial": ap / n_spa if n_spa == n_spa and n_spa
                                     else np.nan,
                     "movable_shafts": movable})
    print(f"  [{k}/{len(feat_cols)}] {fc}", flush=True)

P = pd.DataFrame(rows)
P.to_csv(os.path.join(R, "TABLE_spatial_null.csv"), index=False)

# ── which features survive under each null? ───────────────────────
def survivors(col):
    out = []
    for feat, g in P.groupby("feature"):
        v = g[col].dropna().to_numpy()
        if len(v) < 20:
            continue
        meds = np.array([np.median(rng.choice(v, len(v), replace=True))
                         for _ in range(5000)])
        out.append({"feature": feat, "n": len(v),
                    "median": float(np.median(v)),
                    "ci_lo": float(np.percentile(meds, 2.5)),
                    "ci_hi": float(np.percentile(meds, 97.5)),
                    "p_boot": float(np.mean(meds <= 1.0))})
    A = pd.DataFrame(out)
    A["q_BH"] = multipletests(A.p_boot.clip(lower=1 / 5000), method="fdr_bh")[1]
    return A.sort_values("median", ascending=False)


I = survivors("lift_iid")
S = survivors("lift_spatial")
S.round(4).to_csv(os.path.join(R, "TABLE_spatial_null_evidence.csv"), index=False)

si = set(I.loc[(I.q_BH < .05) & (I["median"] > 1), "feature"])
ss = set(S.loc[(S.q_BH < .05) & (S["median"] > 1), "feature"])

print("\n" + "=" * 76)
print("SURVIVING MULTIPLICITY CORRECTION UNDER EACH NULL")
print("=" * 76)
print(f"i.i.d. null      : {len(si)} features")
print(f"spatial-shift null: {len(ss)} features\n")
print(f"{'feature':<26}{'λ iid':>8}{'q iid':>9}{'λ spatial':>11}{'q spatial':>11}")
for f_ in sorted(si | ss, key=lambda x: -I.set_index('feature').loc[x, 'median']):
    ri = I.set_index("feature").loc[f_]
    rs = S.set_index("feature").loc[f_] if f_ in set(S.feature) else None
    print(f"{f_:<26}{ri['median']:8.2f}{ri.q_BH:9.4f}"
          f"{(rs['median'] if rs is not None else float('nan')):11.2f}"
          f"{(rs.q_BH if rs is not None else float('nan')):11.4f}")

lost = si - ss
if lost:
    print(f"\nLOST under the spatial null: {sorted(lost)}")
    print("  These features exceed an i.i.d. null but not one that preserves")
    print("  the spatial structure of the treated region: their advantage is")
    print("  attributable to spatial smoothness rather than to identifying")
    print("  this particular volume.")
else:
    print("\nAll features surviving the i.i.d. null also survive the spatial")
    print("null: the advantage is not merely spatial smoothness.")

# ── is lambda higher in lesional participants? ────────────────────
print("\n" + "=" * 76)
print("LESIONAL INTERACTION  (are the survivors detecting the lesion?)")
print("=" * 76)
coh = pd.read_csv(os.path.join(R, "cohort.csv"))
try:
    p4 = pd.read_csv(os.path.join(BASE, "raw", "ds004100", "participants.tsv"),
                     sep="\t")
    p4.columns = [c.strip() for c in p4.columns]
    p4["sub"] = p4[p4.columns[0]].astype(str).str.strip()
    les = p4[["sub", "lesion_status"]].dropna()
    les["lesional"] = les.lesion_status.astype(str).str.upper().eq("LESIONAL")
    M = P.merge(les[["sub", "lesional"]], on="sub", how="inner")
    print(f"{M['sub'].nunique()} participants with lesional status\n")
    print(f"{'feature':<26}{'λ lesional':>12}{'λ non-les':>12}{'p':>9}")
    out = []
    for feat, g in M.groupby("feature"):
        a = g.loc[g.lesional, "lift_iid"].dropna()
        b = g.loc[~g.lesional, "lift_iid"].dropna()
        if len(a) < 5 or len(b) < 5:
            continue
        p_ = stats.mannwhitneyu(a, b).pvalue
        out.append({"feature": feat, "median_lesional": a.median(),
                    "median_nonlesional": b.median(), "p": p_})
    O = pd.DataFrame(out)
    O["q_BH"] = multipletests(O.p, method="fdr_bh")[1]
    O = O.sort_values("p")
    O.round(4).to_csv(os.path.join(R, "TABLE_lesional_interaction.csv"),
                      index=False)
    for _, r in O.head(10).iterrows():
        print(f"{r.feature:<26}{r.median_lesional:12.2f}"
              f"{r.median_nonlesional:12.2f}{r.p:9.4f}")
    print(f"\nfeatures with q < 0.05: {(O.q_BH < .05).sum()} of {len(O)}")
    print("A positive result here would support the interpretation that the")
    print("surviving low-frequency features track structural lesion rather")
    print("than epileptogenicity specifically.")
except Exception as e:
    print("  could not run:", e)

print(f"\ntables written to {R}")
