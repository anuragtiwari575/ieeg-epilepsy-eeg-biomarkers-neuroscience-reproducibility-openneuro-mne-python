"""Preprocessing and per-channel feature extraction.

Every feature function takes windows of shape (n_windows, n_channels, n_times)
and returns a DataFrame indexed by channel with one column per feature.
"""
from __future__ import annotations
import warnings

import numpy as np
import pandas as pd
from scipy import signal as sps

from . import config as C


# ------------------------------------------------------------------ preprocess
def preprocess(raw, dataset: str):
    """Notch, bandpass, resample, epoch. Returns (windows[W,C,T], sfreq)."""
    import mne
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        line = C.LINE_FREQ.get(dataset, 60.0)
        nyq = raw.info["sfreq"] / 2
        freqs = [f for f in np.arange(line, nyq, line) if f < nyq - 1]
        if freqs:
            raw.notch_filter(freqs, verbose="ERROR")

        hi = min(C.BANDPASS[1], nyq - 1)
        raw.filter(C.BANDPASS[0], hi, verbose="ERROR")

        if raw.info["sfreq"] > C.TARGET_SFREQ:
            raw.resample(C.TARGET_SFREQ, verbose="ERROR")

    sf = float(raw.info["sfreq"])
    x = raw.get_data()                                  # (C, T)
    n = int(C.WINDOW_SEC * sf)
    nw = min(x.shape[1] // n, C.MAX_WINDOWS)
    if nw < 1:
        raise ValueError("recording shorter than one window")
    w = x[:, : nw * n].reshape(x.shape[0], nw, n).transpose(1, 0, 2)

    # drop flat / non-finite channels' influence by zero-variance guard
    return np.nan_to_num(w), sf


def _zscore_win(w):
    m = w.mean(axis=-1, keepdims=True)
    s = w.std(axis=-1, keepdims=True)
    return (w - m) / np.where(s < 1e-12, 1.0, s)


# ------------------------------------------------------------------ spectral
def spectral_features(w: np.ndarray, sf: float) -> pd.DataFrame:
    nper = min(w.shape[-1], int(2 * sf))
    f, p = sps.welch(w, fs=sf, nperseg=nper, axis=-1)     # (W, C, F)
    p = np.maximum(p, 1e-20)
    total = p.sum(axis=-1)

    out = {}
    for name, (lo, hi) in C.BANDS.items():
        m = (f >= lo) & (f < min(hi, sf / 2 - 1))
        if m.sum() == 0:
            continue
        bp = p[..., m].sum(axis=-1)
        out[f"bp_{name}"] = np.log10(bp).mean(axis=0)
        out[f"rel_{name}"] = (bp / total).mean(axis=0)

    # aperiodic slope (log-log fit, 1-45 Hz), a cheap 1/f exponent proxy
    m = (f >= 1) & (f <= min(45, sf / 2 - 1))
    lf, lp = np.log10(f[m]), np.log10(p[..., m])
    A = np.vstack([lf, np.ones_like(lf)]).T
    coef, *_ = np.linalg.lstsq(A, lp.reshape(-1, m.sum()).T, rcond=None)
    out["slope"] = coef[0].reshape(p.shape[0], p.shape[1]).mean(axis=0)
    out["offset"] = coef[1].reshape(p.shape[0], p.shape[1]).mean(axis=0)

    pn = p / p.sum(axis=-1, keepdims=True)
    out["spec_entropy"] = (-(pn * np.log(pn)).sum(axis=-1)).mean(axis=0)
    out["line_length"] = np.abs(np.diff(w, axis=-1)).mean(axis=(0, 2))
    out["variance"] = w.var(axis=-1).mean(axis=0)
    z = _zscore_win(w)
    out["kurtosis"] = (z ** 4).mean(axis=-1).mean(axis=0)
    return pd.DataFrame(out)


# ------------------------------------------------------------------ graph
def connectivity_matrix(w: np.ndarray) -> np.ndarray:
    """Mean absolute correlation matrix across windows. (C, C)"""
    mats = []
    for win in w:
        z = _zscore_win(win)
        c = np.corrcoef(z)
        mats.append(np.nan_to_num(np.abs(c)))
    M = np.mean(mats, axis=0)
    np.fill_diagonal(M, 0.0)
    return M


def graph_features(M: np.ndarray) -> pd.DataFrame:
    deg = M.sum(axis=1)
    thr = np.percentile(M, 80)
    B = (M > thr).astype(float)
    bdeg = B.sum(axis=1)
    try:
        ev = np.abs(np.linalg.eigh(M)[1][:, -1])
    except np.linalg.LinAlgError:
        ev = np.zeros(M.shape[0])
    # local clustering on the binarised graph
    tri = np.einsum("ij,jk,ki->i", B, B, B)
    denom = bdeg * (bdeg - 1)
    clus = np.divide(tri, np.where(denom == 0, 1, denom))
    return pd.DataFrame({
        "deg_strength": deg, "deg_binary": bdeg,
        "eigencentrality": ev, "clustering": clus,
    })


# ------------------------------------------------------------------ source-sink
def _fit_A(X: np.ndarray, ridge: float) -> np.ndarray:
    """Least-squares A for x(t+1) = A x(t) with ridge regularisation."""
    Xt, Xn = X[:, :-1], X[:, 1:]
    G = Xt @ Xt.T
    G += ridge * np.trace(G) / max(G.shape[0], 1) * np.eye(G.shape[0])
    return np.linalg.solve(G, Xt @ Xn.T).T


def _stable_A(X: np.ndarray, ridge0: float = C.SSI_RIDGE) -> np.ndarray:
    """Adaptive ridge: increase until the fitted system is stable (rho <= 1).

    The published lambda=1e-4 destabilises some patients; EZFragility solves this
    with a binary search over lambda. Same idea here.
    """
    lo, hi = ridge0, 10.0
    A = _fit_A(X, lo)
    if np.max(np.abs(np.linalg.eigvals(A))) <= 1.0:
        return A
    for _ in range(20):
        mid = np.sqrt(lo * hi)
        A = _fit_A(X, mid)
        if np.max(np.abs(np.linalg.eigvals(A))) <= 1.0:
            hi = mid
        else:
            lo = mid
    return _fit_A(X, hi)


def _rank01(v: np.ndarray) -> np.ndarray:
    r = pd.Series(v).rank(method="average").to_numpy() - 1
    return r / max(len(v) - 1, 1)


def ssi_features(w: np.ndarray, sf: float) -> pd.DataFrame:
    """Source-sink index per the ds003876 workbook definitions.

        sink index       = sqrt(2) - dist(node, optimal sink)
        source index     = sqrt(2) - dist(node, optimal source)
        source influence = sum_j A_ij * source_index_j
        sink connectivity= sum_j A_ij * sink_index_j
        SSI              = sink_index * source_influence * sink_connectivity

    Coordinates are the rank-normalised row sum (outgoing influence) and column
    sum (incoming influence) of |A|. Optimal sink = high incoming, low outgoing.

    NOTE: validate against derivatives/sourcesink/.../*_ss_ind.mat before use.
    """
    nwin = int(C.SSI_WINDOW_SEC * sf)
    step = int(C.SSI_STEP_SEC * sf)
    root2 = np.sqrt(2.0)
    acc = []

    for win in w:
        Z = _zscore_win(win)
        for s in range(0, Z.shape[1] - nwin, step):
            X = Z[:, s:s + nwin]
            if X.shape[1] < X.shape[0] + 2:      # underdetermined
                continue
            try:
                A = _stable_A(X)
            except np.linalg.LinAlgError:
                continue
            Aa = np.abs(A)
            r_out = _rank01(Aa.sum(axis=1))      # how much it sends
            r_in = _rank01(Aa.sum(axis=0))       # how much it receives

            sink = root2 - np.hypot(r_in - 1.0, r_out - 0.0)
            source = root2 - np.hypot(r_in - 0.0, r_out - 1.0)
            src_infl = Aa @ source
            snk_conn = Aa @ sink
            acc.append(np.vstack([sink, source, src_infl, snk_conn,
                                  sink * src_infl * snk_conn]))

    if not acc:
        n = w.shape[1]
        return pd.DataFrame({k: np.zeros(n) for k in
                             ["sink_index", "source_index", "source_influence",
                              "sink_connectivity", "ssi"]})

    m = np.mean(acc, axis=0)
    return pd.DataFrame({
        "sink_index": m[0], "source_index": m[1],
        "source_influence": m[2], "sink_connectivity": m[3], "ssi": m[4],
    })


def fragility_features(w: np.ndarray, sf: float) -> pd.DataFrame:
    """Row-perturbation fragility: minimum-norm row perturbation moving the
    system to the stability boundary. Simplified from Li et al. (2021)."""
    nwin = int(C.SSI_WINDOW_SEC * sf)
    step = int(C.SSI_STEP_SEC * sf)
    acc = []
    for win in w:
        Z = _zscore_win(win)
        for s in range(0, Z.shape[1] - nwin, step):
            X = Z[:, s:s + nwin]
            if X.shape[1] < X.shape[0] + 2:
                continue
            try:
                A = _stable_A(X)
            except np.linalg.LinAlgError:
                continue
            rho = np.max(np.abs(np.linalg.eigvals(A)))
            rn = np.linalg.norm(A, axis=1)
            acc.append(np.abs(1.0 - rho) / np.where(rn < 1e-9, 1e-9, rn))
    if not acc:
        return pd.DataFrame({"fragility": np.zeros(w.shape[1])})
    f = np.mean(acc, axis=0)
    return pd.DataFrame({"fragility": 1.0 - f / (f.max() + 1e-12)})


# ------------------------------------------------------------------ driver
FAMILIES = {
    "spectral": lambda w, sf, M: spectral_features(w, sf),
    "graph":    lambda w, sf, M: graph_features(M),
    "ssi":      lambda w, sf, M: ssi_features(w, sf),
    "fragility": lambda w, sf, M: fragility_features(w, sf),
}


def compute_all(w: np.ndarray, sf: float, families=None) -> pd.DataFrame:
    families = families or list(FAMILIES)
    M = connectivity_matrix(w) if "graph" in families else None
    parts = []
    for fam in families:
        try:
            df = FAMILIES[fam](w, sf, M)
            df.columns = [f"{fam}::{c}" for c in df.columns]
            parts.append(df)
        except Exception as e:                     # one family failing is survivable
            warnings.warn(f"feature family {fam} failed: {e}")
    return pd.concat(parts, axis=1)
