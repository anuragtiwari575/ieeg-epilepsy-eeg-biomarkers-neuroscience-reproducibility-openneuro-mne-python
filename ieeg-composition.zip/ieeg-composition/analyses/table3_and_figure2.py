"""
Reconcile Table 3 and Figure 2 with the corrected composition model.

THE PROBLEM
    Table 3 and the Figure 2 caption still carry numbers from the earlier model,
    in which lesional status and surgical target were coerced to zero for the 22
    ds003876 participants for whom they were never recorded. That model gave
    19 of 28 features above R^2 = 0.30 for the random forest. The corrected
    primary model -- four covariates observed in both cohorts -- gives 18 of 28,
    which is what the Abstract and Results now report.

    Ridge and gradient boosting were also never rerun on the corrected
    covariates, so Table 3 currently mixes two models.

THIS SCRIPT
    Runs all four learners on the corrected covariate set, prints the exact
    Table 3 rows to paste, and regenerates Figure 2 from the corrected output.
"""
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.inspection import permutation_importance
from sklearn.metrics import r2_score

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")

perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))
coh = pd.read_csv(os.path.join(R, "cohort.csv"))

part = []
for ds in ["ds003876", "ds004100"]:
    p = pd.read_csv(os.path.join(BASE, "raw", ds, "participants.tsv"), sep="\t")
    p.columns = [c.strip() for c in p.columns]
    p["sub"] = p[p.columns[0]].astype(str).str.strip()
    p["dataset"] = ds
    part.append(p)
part = pd.concat(part, ignore_index=True)

u = coh[coh.usable].merge(part, on=["sub", "dataset"], how="left",
                          suffixes=("", "_p"))
u["centre"] = u["site"].fillna("HUP") if "site" in u else u["dataset"]
u["is_resection"] = (u.therapy == "RESECTION").astype(float)
u["is_ecog"] = (u.implant == "ECOG").astype(float)

CORE = ["prevalence", "is_resection", "is_ecog", "n_valid"]
FROM_COH = [c for c in CORE if c != "prevalence"]

MODELS = {
    "Ordinary least squares": LinearRegression(),
    "Random forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                                           random_state=0, n_jobs=-1),
    "Ridge regression": Ridge(alpha=1.0),
    "Gradient boosting": GradientBoostingRegressor(random_state=0),
}

D = perf.merge(u[["sub", "centre"] + FROM_COH], on="sub", how="inner")

rows = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "lift_emp"] + CORE)
    if len(g) < 25:
        continue
    X = g[CORE].to_numpy(float)
    grp = g.centre.fillna("NA").to_numpy()
    ng = len(np.unique(grp))
    cv = GroupKFold(n_splits=min(4, ng)) if ng > 1 else 4
    row = {"feature": feat, "n": len(g)}
    for name, m in MODELS.items():
        for tgt in ["auprc", "lift_emp"]:
            y = g[tgt].to_numpy()
            try:
                pred = cross_val_predict(m, X, y, cv=cv, groups=grp)
            except Exception:
                pred = cross_val_predict(m, X, y, cv=4)
            row[f"{name}|{tgt}"] = r2_score(y, pred)
    rows.append(row)

A = pd.DataFrame(rows)
A.round(4).to_csv(os.path.join(R, "TABLE3_all_learners_corrected.csv"), index=False)

print("=" * 76)
print("TABLE 3 — corrected covariate set, all 77 participants")
print("=" * 76)
print(f"{'model':<26}{'R2 AP':>9}{'R2 lift':>10}{'AP>0.3':>9}{'lift>0.3':>10}")
for name in MODELS:
    a, l = A[f"{name}|auprc"], A[f"{name}|lift_emp"]
    print(f"{name:<26}{a.median():9.2f}{l.median():10.2f}"
          f"{int((a>.3).sum()):6d}/28{int((l>.3).sum()):7d}/28")

print("\nLaTeX rows for Table 3:\n")
for name in MODELS:
    a, l = A[f"{name}|auprc"], A[f"{name}|lift_emp"]
    lv = f"{l.median():.2f}".replace("-", "$-$")
    bold = name == "Ordinary least squares"
    ap = f"\\textbf{{{a.median():.2f}}}" if bold else f"{a.median():.2f}"
    cnt = (f"\\textbf{{{int((a>.3).sum())} / 28}}" if bold
           else f"{int((a>.3).sum())} / 28")
    print(f"{name} & {ap} & {lv} & {cnt} & {int((l>.3).sum())} / 28\\\\")

best = A.set_index("feature")["Random forest|auprc"].idxmax()
g = D[D.feature == best].dropna(subset=["auprc"] + CORE)
rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                           random_state=0, n_jobs=-1).fit(g[CORE], g.auprc)
imp = permutation_importance(rf, g[CORE], g.auprc, n_repeats=50, random_state=0)
print(f"\nPermutation importance for {best}:")
for n_, m_, s_ in sorted(zip(CORE, imp.importances_mean, imp.importances_std),
                         key=lambda x: -x[1]):
    print(f"  {n_:14s} {m_:+.3f} +/- {s_:.3f}")

print(f"\nRandom forest: median {A['Random forest|auprc'].median():.3f}, "
      f"max {A['Random forest|auprc'].max():.3f}, "
      f"{int((A['Random forest|auprc']>.3).sum())} of 28 above 0.30")
print("This is the number the Abstract, Results, Table 3 and the Figure 2")
print("caption must all agree on.")

# ══════════════════════════════════════════════════════════════════
# FIGURE 2 regenerated from the corrected output
# ══════════════════════════════════════════════════════════════════
mpl.rcParams.update({
    "font.size": 8, "font.family": "serif", "axes.linewidth": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.dpi": 300,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.6,
})
BLUE, GREEN, RED, GREY, GRID = "#2a6fb5", "#1a9e6e", "#c33", "#7a7a7a", "#e3e3dd"


def short(f):
    return (f.replace("spectral::", "").replace("ssi::", "SSI ")
             .replace("fragility::", "").replace("graph::", "graph ")
             .replace("_", " "))


C = pd.read_csv(os.path.join(R, "TABLE_correlation_robustness.csv"))
B = pd.read_csv(os.path.join(R, "TABLE_variance_decomposition.csv"))

fig = plt.figure(figsize=(7.1, 10.2))
gs = fig.add_gridspec(3, 1, height_ratios=[1.32, 1.32, 0.70], hspace=0.46)

ax = fig.add_subplot(gs[0])
c = C.sort_values("r").reset_index(drop=True)
y = np.arange(len(c))
if "loco_min" in c:
    ax.hlines(y, c.loco_min, c.loco_max, color=GREY, lw=4.0, alpha=.22, zorder=2)
ax.hlines(y, c.ci_lo, c.ci_hi, color=BLUE, lw=1.3, zorder=3)
ax.plot(c.r, y, "o", ms=3.2, color=BLUE, zorder=4)
ax.axvline(0, color="k", lw=0.7, zorder=1)
ax.set_yticks(y); ax.set_yticklabels([short(f) for f in c.feature], fontsize=6.6)
ax.set_ylim(-0.8, len(c) - 0.2); ax.set_xlim(-0.04, 1.0)
ax.set_xlabel("correlation of average precision with prevalence ($r$)", labelpad=2)
ax.grid(axis="x", color=GRID, lw=0.5, zorder=0); ax.set_axisbelow(True)
ax.plot([], [], "o-", color=BLUE, ms=3.2, lw=1.3, label="$r$ (bootstrap 95% CI)")
ax.plot([], [], "-", color=GREY, lw=4.0, alpha=.35, label="leave-one-centre-out range")
ax.legend(loc="upper left", frameon=False, handlelength=1.6)
ax.set_title("A.  Average precision tracks prevalence for every feature",
             loc="left", fontsize=8.6, fontweight="bold", pad=6)

ax = fig.add_subplot(gs[1])
a = A[["feature", "Random forest|auprc", "Random forest|lift_emp"]].copy()
a.columns = ["feature", "ap", "lift"]
a = a.sort_values("ap").reset_index(drop=True)
y = np.arange(len(a))
ax.barh(y - .21, a.ap, height=.40, color=BLUE, zorder=3,
        label="predicting average precision")
ax.barh(y + .21, a.lift, height=.40, color=GREEN, zorder=3,
        label=r"predicting normalised lift $\lambda$")
ax.axvline(0, color="k", lw=0.8, zorder=4)
ax.axvline(0.3, color=RED, ls=":", lw=1.0, zorder=4)
ax.set_yticks(y); ax.set_yticklabels([short(f) for f in a.feature], fontsize=6.6)
ax.set_ylim(-1.4, len(a) - 0.2); ax.set_xlim(-0.75, 0.80)
ax.set_xlabel("cross-validated $R^2$   (leave-one-centre-out)", labelpad=2)
ax.text(0.315, 0.5, "$R^2$ = 0.30", color=RED, fontsize=6.4, rotation=90, va="bottom")
ax.grid(axis="x", color=GRID, lw=0.5, zorder=0); ax.set_axisbelow(True)
ax.legend(loc="lower left", frameon=False, handlelength=1.4,
          bbox_to_anchor=(0.005, 0.005))
ax.set_title("B.  Composition alone — no iEEG signal — predicts reported "
             "performance", loc="left", fontsize=8.6, fontweight="bold", pad=6)

ax = fig.add_subplot(gs[2])
facs = [f for f in ["prevalence", "therapy", "implant", "lesional", "target",
                    "array size", "all combined"] if f in B.columns]
med = B.groupby("metric")[facs].median()
x = np.arange(len(facs))
ax.bar(x - .19, med.loc["auprc", facs], width=.38, color=BLUE, zorder=3,
       label="average precision")
ax.bar(x + .19, med.loc["lift_emp", facs], width=.38, color=GREEN, zorder=3,
       label=r"normalised lift $\lambda$")
for i, f in enumerate(facs):
    ax.text(i - .19, med.loc["auprc", f] + .013, f"{med.loc['auprc', f]:.2f}",
            ha="center", fontsize=6.2)
    ax.text(i + .19, med.loc["lift_emp", f] + .013,
            f"{med.loc['lift_emp', f]:.2f}", ha="center", fontsize=6.2)
ax.set_xticks(x); ax.set_xticklabels(facs, fontsize=7)
ax.set_ylabel("median $R^2$\nacross 28 features", fontsize=7.4)
ax.set_ylim(0, float(med.values.max()) * 1.42)
ax.grid(axis="y", color=GRID, lw=0.5, zorder=0); ax.set_axisbelow(True)
ax.legend(loc="upper center", frameon=False, ncol=2, handlelength=1.4,
          bbox_to_anchor=(0.45, 1.0))
ax.set_title("C.  Variance in each metric explained by each composition factor",
             loc="left", fontsize=8.6, fontweight="bold", pad=6)

for ext in ("png", "pdf"):
    fig.savefig(os.path.join(R, f"FIG2_composition_prediction.{ext}"))
plt.close(fig)
print("\nFigure 2 regenerated from the corrected model")

SUB = os.path.join(BASE, "submission")
if os.path.isdir(SUB):
    import shutil
    shutil.copy(os.path.join(R, "FIG2_composition_prediction.pdf"),
                os.path.join(SUB, "FIG2_composition_prediction.pdf"))
    print("staged into submission/")
