"""
Extract the exact OpenNeuro dataset versions to complete the data availability
statement. The manuscript currently carries vX.X.X placeholders.

Reads dataset_description.json and CHANGES from each raw dataset folder and
prints the DOI line to paste into the manuscript.
"""
import json
import os

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"

print("Paste these into the data availability statement:\n")
for ds in ["ds003876", "ds004100", "ds003844"]:
    d = os.path.join(BASE, "raw", ds)
    version, doi, name = None, None, None

    desc = os.path.join(d, "dataset_description.json")
    if os.path.exists(desc):
        try:
            j = json.load(open(desc, encoding="utf-8"))
        except Exception:
            j = {}
        name = j.get("Name")
        # OpenNeuro records the DOI here on most releases
        doi = j.get("DatasetDOI") or j.get("DOI")
        version = j.get("DatasetVersion") or j.get("BIDSVersion")

    # CHANGES usually opens with the released version number
    ch = os.path.join(d, "CHANGES")
    first = None
    if os.path.exists(ch):
        with open(ch, encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip():
                    first = line.strip()
                    break

    print(f"── {ds}")
    if name:
        print(f"   name          : {name}")
    if doi:
        print(f"   DatasetDOI    : {doi}")
    if first:
        print(f"   CHANGES (top) : {first}")
    if not doi:
        print(f"   No DOI recorded locally. Take it from")
        print(f"   https://openneuro.org/datasets/{ds}  (shown as")
        print(f"   doi:10.18112/openneuro.{ds}.vX.X.X on the dataset page)")
    print()

print("Then replace each vX.X.X in the manuscript with the version you")
print("actually downloaded, so the analysis is reproducible against it.")
