"""
Recompute every per-participant metric under LEAVE-ONE-PARTICIPANT-OUT
orientation, so that feature direction can be made the primary protocol rather
than a sensitivity analysis.

Why this is needed
------------------
Feature orientation was resolved from the pooled point-biserial correlation,
using the same labels on which performance is then evaluated. The practical
effect is small (0.3% of signs flip; r = 0.99 between the two), but there is no
reason to leave the opening. Making LOPO primary requires recomputing the
downstream numbers, because orientation changes average precision itself, not
only the lift: AP(y, s) and AP(y, -s) differ.

Produces
--------
    per_patient_metrics_loo.csv              parallel to the pooled version
    TABLE_localization_evidence_BH_loo.csv   the five-surviving-features test
    TABLE_correlation_robustness_loo.csv     corr(AP, prevalence) per feature
    orientation_comparison.txt               pooled vs LOPO, side by side

If the conclusions are unchanged, switch the manuscript to the LOPO numbers and
demote pooled orientation to the sensitivity analysis.
"""
import os
import glob
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score
from statsmodels.stats.multitest import multipletests

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")
FEAT = os.path.join(BASE, "features")
rng = np.random.default_rng(0)
MIN_POS, TOP_K = 2, 0.10


def empirical_null_ap(y, n_perm=200, seed=0):
    y = np.asarray(y).astype(bool)
    if y.sum() < 1 or y.all():
        return np.nan
    g = np.random.default_rng(seed)
    return float(np.mean([average_precision_score(y, g.random(len(y)))
                          for _ in range(n_perm)]))


files = sorted(glob.glob(os.path.join(FEAT, "*.parquet")))
if not files:
    raise SystemExit(f"no feature files in {FEAT}")
allf = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
feat_cols = [c for c in allf.columns if "::" in c]
print(f"{len(files)} participants, {len(feat_cols)} features\n")

rows = []
for k, fc in enumerate(feat_cols, 1):
    pat = []
    for (ds, sub), g in allf.groupby(["dataset", "sub"]):
        y = g["rz"].to_numpy().astype(bool)
        if y.sum() < MIN_POS or y.all():
            continue
        pat.append({"sub": sub, "dataset": ds,
                    "score": g[fc].to_numpy(float), "y": y})
    if len(pat) < 10:
        continue

    # each participant's contribution to the orientation decision
    contrib = []
    for p in pat:
        ok = np.isfinite(p["score"])
        if ok.sum() > 5 and len(np.unique(p["y"][ok])) > 1:
            r_, _ = stats.pointbiserialr(p["y"][ok].astype(float), p["score"][ok])
            contrib.append(r_ if np.isfinite(r_) else 0.0)
        else:
            contrib.append(0.0)
    contrib = np.asarray(contrib)
    pooled_sign = 1.0 if np.nanmean(contrib) >= 0 else -1.0

    for i, p in enumerate(pat):
        loo_sign = 1.0 if np.nanmean(np.delete(contrib, i)) >= 0 else -1.0
        y = p["y"]
        null = empirical_null_ap(y)
        n, npos = len(y), int(y.sum())
        out = {"sub": p["sub"], "dataset": p["dataset"], "feature": fc,
               "prevalence": npos / n, "null_ap": null,
               "sign_loo": loo_sign, "sign_pooled": pooled_sign,
               "sign_flipped": loo_sign != pooled_sign}
        for tag, sgn in (("loo", loo_sign), ("pooled", pooled_sign)):
            s = sgn * p["score"]
            ok = np.isfinite(s)
            ap = average_precision_score(y[ok], s[ok])
            ranks = stats.rankdata(-s[ok])
            kk = max(1, int(round(TOP_K * ok.sum())))
            out[f"auprc_{tag}"] = ap
            out[f"lift_{tag}"] = ap / null if null else np.nan
            out[f"norm_rank_{tag}"] = 1.0 - ranks[y[ok]].mean() / ok.sum()
            out[f"prec_at_k_{tag}"] = y[ok][np.argsort(-s[ok])][:kk].mean()
        rows.append(out)
    print(f"  [{k}/{len(feat_cols)}] {fc}", flush=True)

P = pd.DataFrame(rows)
P.to_csv(os.path.join(R, "per_patient_metrics_loo.csv"), index=False)

# ── localization test under each orientation ─────────────────────
def localization(col):
    out = []
    for feat, g in P.groupby("feature"):
        v = g[col].dropna().to_numpy()
        if len(v) < 20:
            continue
        meds = np.array([np.median(rng.choice(v, len(v), replace=True))
                         for _ in range(5000)])
        out.append({"feature": feat, "median_lift": float(np.median(v)),
                    "ci_lo": float(np.percentile(meds, 2.5)),
                    "ci_hi": float(np.percentile(meds, 97.5)),
                    "p_boot": float(np.mean(meds <= 1.0))})
    A = pd.DataFrame(out)
    A["q_BH"] = multipletests(A.p_boot.clip(lower=1 / 5000), method="fdr_bh")[1]
    return A.sort_values("median_lift", ascending=False)


L_loo = localization("lift_loo")
L_pool = localization("lift_pooled")
L_loo.round(4).to_csv(os.path.join(R, "TABLE_localization_evidence_BH_loo.csv"),
                      index=False)

# ── corr(AP, prevalence) under each orientation ──────────────────
def corrs(col):
    out = []
    for feat, g in P.groupby("feature"):
        g = g.dropna(subset=[col, "prevalence"])
        if len(g) < 20:
            continue
        r_, p_ = stats.pearsonr(g.prevalence, g[col])
        out.append({"feature": feat, "r": r_, "p": p_})
    return pd.DataFrame(out)


C_loo, C_pool = corrs("auprc_loo"), corrs("auprc_pooled")
C_loo.round(4).to_csv(os.path.join(R, "TABLE_correlation_robustness_loo.csv"),
                      index=False)

# ── report ───────────────────────────────────────────────────────
def surv(A):
    return set(A.loc[(A.q_BH < .05) & (A.median_lift > 1), "feature"])

s_loo, s_pool = surv(L_loo), surv(L_pool)
lines = []
lines.append("=" * 74)
lines.append("ORIENTATION: LEAVE-ONE-PARTICIPANT-OUT vs POOLED")
lines.append("=" * 74)
lines.append(f"participant-feature signs flipped : {100*P.sign_flipped.mean():.2f}%")
lines.append(f"mean lift, pooled                 : {P.lift_pooled.mean():.3f}")
lines.append(f"mean lift, LOPO                   : {P.lift_loo.mean():.3f}")
lines.append(f"correlation between the two       : "
             f"r = {stats.pearsonr(P.lift_pooled, P.lift_loo)[0]:.4f}")
lines.append("")
lines.append(f"features surviving BH, pooled     : {len(s_pool)}")
lines.append(f"features surviving BH, LOPO       : {len(s_loo)}")
lines.append(f"identical set                     : {s_loo == s_pool}")
if s_loo != s_pool:
    lines.append(f"  only in LOPO   : {sorted(s_loo - s_pool)}")
    lines.append(f"  only in pooled : {sorted(s_pool - s_loo)}")
lines.append("")
lines.append("surviving under LOPO:")
for _, r in L_loo[(L_loo.q_BH < .05) & (L_loo.median_lift > 1)].iterrows():
    lines.append(f"  {r.feature:26s} median {r.median_lift:.2f} "
                 f"({r.ci_lo:.2f}-{r.ci_hi:.2f})  q = {r.q_BH:.4f}")
lines.append("")
lines.append(f"corr(AP, prevalence), pooled : "
             f"{C_pool.r.min():.2f}-{C_pool.r.max():.2f}")
lines.append(f"corr(AP, prevalence), LOPO   : "
             f"{C_loo.r.min():.2f}-{C_loo.r.max():.2f}")
lines.append(f"all LOPO correlations positive and p < 0.05: "
             f"{bool((C_loo.r > 0).all() and (C_loo.p < .05).all())}")
lines.append("")
lines.append("If the surviving set and the correlation range are unchanged, the")
lines.append("manuscript can report the LOPO numbers as primary and demote")
lines.append("pooled orientation to the sensitivity analysis.")

txt = "\n".join(lines)
print("\n" + txt)
open(os.path.join(R, "orientation_comparison.txt"), "w", encoding="utf-8").write(txt)
print(f"\nwritten to {R}")
