"""
Final numerical consistency check.

Extracts every reported figure from the manuscript source and cross-checks it
against the analysis outputs in results/. Flags any value that appears in the
text but does not match the data, and any placeholder still outstanding.

Run from the folder containing clinph_manuscript.tex, with results/ reachable.
"""
import os
import re
import numpy as np
import pandas as pd

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
TEX = os.path.join(BASE, "submission", "clinph_manuscript.tex")

s = open(TEX, encoding="utf-8").read()
problems, checks = [], 0


def check(label, expected, pattern, tol=0.02):
    """Confirm `expected` appears in the text where `pattern` matches."""
    global checks
    checks += 1
    found = re.findall(pattern, s)
    if not found:
        problems.append(f"NOT MENTIONED  {label}: expected {expected}")
        return
    vals = []
    for f in found:
        f = f if isinstance(f, str) else f[0]
        try:
            vals.append(float(f.replace(",", "")))
        except ValueError:
            pass
    if not vals:
        return
    if not any(abs(v - expected) <= max(tol, abs(expected) * tol) for v in vals):
        problems.append(f"MISMATCH       {label}: text has {sorted(set(vals))}, "
                        f"data says {expected}")


# ── ground truth from the analysis outputs ────────────────────────
coh = pd.read_csv(os.path.join(R, "cohort.csv"))
u = coh[coh.usable]
perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))

n_total = len(u)
n_free = int(u.seizure_free.sum())
n_poor = n_total - n_free
prev_min, prev_max = 100 * u.prevalence.min(), 100 * u.prevalence.max()
n_elec = int(u.n_valid.sum())
mean_ch, sd_ch = u.n_valid.mean(), u.n_valid.std()
n_feat = perf.feature.nunique()

print("=" * 74)
print("GROUND TRUTH FROM results/")
print("=" * 74)
print(f"participants        : {n_total}  ({n_free} Engel I / {n_poor} Engel >=II)")
print(f"electrodes          : {n_elec}  ({mean_ch:.0f} +/- {sd_ch:.0f} per participant)")
print(f"prevalence range    : {prev_min:.1f}% - {prev_max:.1f}%  "
      f"({prev_max/prev_min:.0f}-fold)")
print(f"features            : {n_feat}")
by_ds = u.groupby("dataset").size().to_dict()
print(f"by dataset          : {by_ds}")

# ── cross-check against the text ──────────────────────────────────
check("total participants", n_total, r"(\d+)\s+participants (?:and|\()")
check("Engel I", n_free, r"(\d+)\s*/\s*\d+\s*\(free")
check("electrodes total", n_elec, r"([\d,]+)\s+analysable electrodes", tol=0.001)
check("mean channels", round(mean_ch), r"\$?(\d+)\s*\\pm\s*\d+\$?\s*\(mean")
check("prevalence min", prev_min, r"(\d+\.\d)\\?%?\s*(?:to|--)\s*65\.8")
check("prevalence max", prev_max, r"1\.7\\?%?\s*(?:to|--)\s*(\d+\.\d)")
check("features count", n_feat, r"(\d+)\s+per-channel features")

for ds, n in by_ds.items():
    tag = ds.replace("ds", "")
    check(f"{ds} n", n, rf"{ds}[^\d]{{0,40}}\$?n\s*=\s*(\d+)")

# ── localization evidence table ───────────────────────────────────
f = os.path.join(R, "TABLE_localization_evidence_BH.csv")
if os.path.exists(f):
    A = pd.read_csv(f)
    col = "q_boot_BH" if "q_boot_BH" in A.columns else "q_BH"
    n_surv = int(((A[col] < .05) & (A.median_lift > 1)).sum())
    print(f"features surviving BH: {n_surv}")
    check("surviving features", n_surv, r"(?:Five|Four|Three|Six|(\d+)) of 28\s+features\s+(?:exceeded|identified)")
    if n_surv != 5:
        problems.append(f"ATTENTION      manuscript says five survive; data says {n_surv}")

# ── composition prediction ────────────────────────────────────────
f = os.path.join(R, "TABLE_composition_only_prediction.csv")
if os.path.exists(f):
    A = pd.read_csv(f)
    print(f"median R2 (AP)       : {A.R2_auprc.median():.3f}   "
          f"max {A.R2_auprc.max():.3f}   above 0.3: {(A.R2_auprc>.3).sum()}")
    print(f"median R2 (lift)     : {A.R2_lift_emp.median():.3f}  "
          f"above 0.3: {(A.R2_lift_emp>.3).sum()}")
    check("max R2", A.R2_auprc.max(), r"cross-validated \$R\^\{?2\}?\$ up to (\d\.\d+)")
    check("features above 0.3", int((A.R2_auprc > .3).sum()),
          r"(\d+) of 28 features (?:exceed|above)")

# ── placeholders ──────────────────────────────────────────────────
print("\n" + "=" * 74)
print("PLACEHOLDERS")
print("=" * 74)
for ph in ["[Author names]", "[Affiliations]", "[name, address, email]",
           "[Funding statement]", "vX.X.X", "[repository]"]:
    if ph in s:
        print(f"  OUTSTANDING  {ph}")
        problems.append(f"PLACEHOLDER    {ph}")
if not any(ph in s for ph in ["[Author names]", "[Affiliations]",
                              "[Funding statement]"]):
    print("  none outstanding")

# ── terminology consistency ───────────────────────────────────────
print("\n" + "=" * 74)
print("TERMINOLOGY")
print("=" * 74)
terms = {
    "'bounded below by' (should only appear for lambda at zero)":
        len(re.findall(r"bounded below by (?:the positive|prevalence)", s)),
    "'chance' used where 'empirical null' is meant":
        len(re.findall(r"below chance", s)),
    "'opposite answers'": s.count("opposite answers"),
    "'entirely independent'": s.count("entirely independent"),
    "'treated volume' in the 79-output section":
        len(re.findall(r"annotated[- ]zone", s)),
}
for k, v in terms.items():
    flag = "  <-- check" if ("should only" in k and v > 0) or \
                            ("opposite answers" in k and v > 0) or \
                            ("entirely independent" in k and v > 0) else ""
    print(f"  {k}: {v}{flag}")

# ── summary ───────────────────────────────────────────────────────
print("\n" + "=" * 74)
print(f"{checks} numerical checks run")
if problems:
    print(f"{len(problems)} item(s) need attention:\n")
    for p_ in problems:
        print("  " + p_)
else:
    print("no discrepancies found")
