"""
OpenNeuro -> Google Drive downloader for the iEEG project.

Designed for Google Colab. Key properties:
  - RESUMABLE: re-running skips files already downloaded. Session death is harmless.
  - SIZE-CHECKED: reports dataset size before you commit to downloading.
  - NO CREDENTIALS: OpenNeuro's S3 buckets are public.

Usage in Colab: copy each CELL below into its own notebook cell.
"""

# ============================================================
# CELL 1 — Mount Drive and install AWS CLI
# ============================================================
"""
from google.colab import drive
drive.mount('/content/drive')

!pip install -q awscli

import os
BASE = "/content/drive/MyDrive/ieeg_project"
RAW  = f"{BASE}/raw"
os.makedirs(RAW, exist_ok=True)
print("Target:", RAW)
"""


# ============================================================
# CELL 2 — CHECK SIZES FIRST (do not skip this)
# ============================================================
"""
# Counts files and total bytes WITHOUT downloading anything.
# ds003876's size has not been independently verified - this tells you.

for ds in ["ds003876", "ds003844", "ds003848"]:
    print(f"\n=== {ds} ===")
    !aws s3 ls --no-sign-request --recursive --summarize s3://openneuro.org/{ds}/ | tail -3
"""
# Expected rough figures:
#   ds003844  ~2.6 GB   (RESPect intraoperative, 6 subjects, 38 recordings)
#   ds003848  ~72 GB    (RESPect long-term, 6 subjects) - OUT OF SCOPE
#   ds003876  unknown   (39 subjects, multicenter interictal) - CHECK THIS
#
# If ds003876 comes back above ~150 GB, stop and reconsider: you may only
# need a subset of tasks (interictal / interictalawake / interictalasleep).


# ============================================================
# CELL 3 — Download metadata only (fast, ~seconds)
# ============================================================
"""
# Pulls just the small text files. This is enough to complete PHASE 0
# and answer the participants.tsv question without any bulk transfer.

for ds in ["ds003876", "ds003844"]:
    !aws s3 sync --no-sign-request \
        s3://openneuro.org/{ds}/ {RAW}/{ds}/ \
        --exclude "*" \
        --include "*.tsv" --include "*.json" \
        --include "README*" --include "CHANGES" \
        --include "dataset_description.json"

print("Metadata done.")
"""


# ============================================================
# CELL 4 — Inspect the metadata (this is PHASE 0)
# ============================================================
"""
import pandas as pd, glob

p = pd.read_csv(f"{RAW}/ds003876/participants.tsv", sep="\t")
print("PARTICIPANTS COLUMNS:", p.columns.tolist())
print(p.head(40).to_string())
print("\nShape:", p.shape)

# Column descriptions, if the sidecar exists
import json, os
sidecar = f"{RAW}/ds003876/participants.json"
if os.path.exists(sidecar):
    print("\nCOLUMN DEFINITIONS:")
    print(json.dumps(json.load(open(sidecar)), indent=2)[:3000])

# One subject's channel table - this is where resection/SOZ flags live
ch = sorted(glob.glob(f"{RAW}/ds003876/sub-*/**/*channels.tsv", recursive=True))
if ch:
    c = pd.read_csv(ch[0], sep="\t")
    print("\nCHANNELS COLUMNS:", c.columns.tolist())
    print(c.head(20).to_string())
    for col in c.columns:
        if c[col].dtype == object and c[col].nunique() < 12:
            print(f"  {col}: {c[col].unique()}")
"""


# ============================================================
# CELL 5 — Full download (only after Cells 2-4 look right)
# ============================================================
"""
# Resumable: sync skips files that already exist with matching size.
# If the session dies, just re-run this cell.

DATASETS = ["ds003844", "ds003876"]      # ds003848 excluded: 72 GB, out of scope

for ds in DATASETS:
    print(f"\n{'='*50}\nDownloading {ds}\n{'='*50}")
    !aws s3 sync --no-sign-request \
        s3://openneuro.org/{ds}/ {RAW}/{ds}/ \
        --no-progress
    print(f"{ds} complete.")
"""


# ============================================================
# CELL 5b — OPTIONAL: ds003848 (72 GB, only if extending to SPES/CCEP)
# ============================================================
"""
# Not needed for the current scope. Download only if you plan the
# CCEP / SPES extension chapter later.

!aws s3 sync --no-sign-request \
    s3://openneuro.org/ds003848/ {RAW}/ds003848/ \
    --no-progress
"""


# ============================================================
# CELL 6 — Verify what actually landed
# ============================================================
"""
import subprocess

for ds in ["ds003844", "ds003876"]:
    path = f"{RAW}/{ds}"
    if not os.path.exists(path):
        print(f"{ds}: MISSING")
        continue
    size  = subprocess.run(['du','-sh',path], capture_output=True, text=True).stdout.split()[0]
    nfile = sum(len(f) for _,_,f in os.walk(path))
    nsub  = len([d for d in os.listdir(path) if d.startswith('sub-')])
    print(f"{ds}: {size}, {nfile} files, {nsub} subjects")

# Local VM disk (separate from Drive - this is what fills up mid-compute)
import shutil
_,_,free = shutil.disk_usage('/content')
print(f"\nLocal VM free: {free/1e9:.1f} GB")
"""


# ============================================================
# FALLBACK — if aws s3 fails
# ============================================================
"""
# openneuro-py is the official client. Slower, but also resumable.
!pip install -q openneuro-py

import openneuro
openneuro.download(dataset="ds003876", target_dir=f"{RAW}/ds003876")

# Or DataLad, if you want per-file lazy fetching rather than a full pull:
# !pip install -q datalad
# !datalad clone https://github.com/OpenNeuroDatasets/ds003876 {RAW}/ds003876
# !cd {RAW}/ds003876 && datalad get sub-*/  # fetch only what you need
"""
