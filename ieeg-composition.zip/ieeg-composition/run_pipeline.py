#!/usr/bin/env python3
"""End-to-end pipeline: BIDS input -> results tables + figures.

Usage
-----
    python run_pipeline.py --stage cohort      # Phase 0: cohort + confound result
    python run_pipeline.py --stage features    # Phase 1-2: per-patient features
    python run_pipeline.py --stage evaluate    # Phase 3-4: metrics + controls
    python run_pipeline.py --stage all

Every stage is resumable. Feature extraction checkpoints per patient, so a
killed Colab session costs nothing - just re-run.
"""
from __future__ import annotations
import argparse
import sys
import traceback
import warnings

import numpy as np
import pandas as pd

from ieeg import config as C
from ieeg import data as D
from ieeg import features as F
from ieeg import evaluate as E


# ================================================================== stage 1
def stage_cohort(datasets) -> pd.DataFrame:
    print("=" * 68, "\nSTAGE 1 - COHORT\n", "=" * 68, sep="")
    coh = D.build_all(datasets)
    C.ensure_dirs()
    coh.to_csv(C.RESULTS / "cohort.csv", index=False)

    print(f"\nSubjects: {len(coh)}   usable: {int(coh.usable.sum())}")
    print("\nBy dataset:")
    print(coh.groupby("dataset").agg(
        n=("sub", "count"), usable=("usable", "sum"),
        seizure_free=("seizure_free", "sum")).to_string())

    u = coh[coh.usable]
    print("\nPrevalence (%) by implant x therapy:")
    print((u.groupby(["implant", "therapy"])["prevalence"]
             .agg(n="count", median=lambda x: round(100 * x.median(), 1),
                  lo=lambda x: round(100 * x.min(), 1),
                  hi=lambda x: round(100 * x.max(), 1))).to_string())

    print("\n" + "-" * 68 + "\nCONFOUND ANALYSIS (Simpson's paradox test)\n" + "-" * 68)
    res = E.confound_analysis(coh)
    for key in ("therapy", "implant_marginal", "implant_within_resection"):
        r = res[key]
        p = r.get("p", np.nan)
        star = "***" if p < 1e-3 else "**" if p < 0.01 else "*" if p < 0.05 else "ns"
        print(f"{key:28s} {r['med1']:6.1f} vs {r['med2']:6.1f}  "
              f"(n={r['n1']},{r['n2']})  p={p:.4g}  {star}")

    print("\nInterpretation: a significant marginal implant effect together with a")
    print("null within-resection effect is the paradox - the marginal comparison")
    print("is confounded by therapy.")

    res["table_2x2"].to_csv(C.RESULTS / "table_2x2.csv", index=False)
    pd.DataFrame([{**{"comparison": k}, **v} for k, v in res.items()
                  if isinstance(v, dict)]).to_csv(
        C.RESULTS / "confound_tests.csv", index=False)
    return coh


# ================================================================== stage 2
def stage_features(coh: pd.DataFrame, families=None, limit=None):
    print("=" * 68, "\nSTAGE 2 - FEATURES\n", "=" * 68, sep="")
    C.ensure_dirs()
    todo = coh[coh.usable].reset_index(drop=True)
    if limit:
        todo = todo.head(limit)

    done = skipped = failed = 0
    for i, row in todo.iterrows():
        out = C.FEATURES / f"{row.dataset}_{row['sub']}.parquet"
        if out.exists():                                  # RESUMABLE
            skipped += 1
            continue
        try:
            raw, names, sf0, labels = D.load_recording(row)
            w, sf = F.preprocess(raw, row.dataset)
            feats = F.compute_all(w, sf, families)
            feats.insert(0, "channel", names[: len(feats)])
            for k in ("rz", "soz", "epz"):
                feats[k] = labels[k][: len(feats)]
            feats["sub"] = row["sub"]
            feats["dataset"] = row.dataset
            feats.to_parquet(out)
            done += 1
            print(f"[{i+1}/{len(todo)}] {row['sub']:16s} "
                  f"{len(feats)}ch {w.shape[0]}win -> ok")
        except Exception as e:
            failed += 1
            print(f"[{i+1}/{len(todo)}] {row['sub']:16s} FAILED: {e}")
            if "--debug" in sys.argv:
                traceback.print_exc()

    print(f"\ncomputed {done}, cached {skipped}, failed {failed}")


# ================================================================== stage 3
def stage_evaluate(coh: pd.DataFrame):
    print("=" * 68, "\nSTAGE 3 - EVALUATION\n", "=" * 68, sep="")
    files = sorted(C.FEATURES.glob("*.parquet"))
    if not files:
        print("No feature files. Run --stage features first.")
        return
    allf = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
    feat_cols = [c for c in allf.columns if "::" in c]
    print(f"{len(files)} patients, {len(feat_cols)} features")

    # ---- assemble per-feature patient rows
    perf, controls = [], []
    for fc in feat_cols:
        rows = []
        for (ds, sub), g in allf.groupby(["dataset", "sub"]):
            y = g["rz"].to_numpy().astype(bool)
            if y.sum() < C.MIN_POSITIVE or y.all():
                continue
            rows.append({"sub": sub, "dataset": ds,
                         "score": g[fc].to_numpy(float), "y": y})
        if len(rows) < 5:
            continue
        perf.append(E.evaluate_feature(rows, fc))
        controls.append(E.permutation_control(rows, fc, n_perm=50))
    if not perf:
        print("Not enough patients for evaluation.")
        return

    perf = pd.concat(perf, ignore_index=True)
    ctrl = pd.DataFrame(controls)
    perf.to_csv(C.RESULTS / "per_patient_metrics.csv", index=False)
    ctrl.to_csv(C.RESULTS / "permutation_controls.csv", index=False)

    # ---- GATE 3: permutation must collapse to lift ~ 1
    print("\n" + "-" * 68 + "\nGATE 3 - NEGATIVE CONTROLS\n" + "-" * 68)
    bad = ctrl[(ctrl.perm_ci_lo > 1.15) | (ctrl.perm_ci_hi < 0.85)]
    print(f"permuted mean lift: {ctrl.perm_mean_lift.mean():.3f} "
          f"(should be ~1.00)")
    if len(bad):
        print(f"!! {len(bad)} features FAIL the permutation control - "
              f"investigate leakage before trusting any result:")
        print(bad[["feature", "perm_mean_lift"]].head(10).to_string(index=False))
    else:
        print("PASS - permutation collapses to prevalence for all features.")

    # ---- summaries
    print("\n" + "-" * 68 + "\nTOP FEATURES BY MEAN LIFT (null = 1.0)\n" + "-" * 68)
    summ = (perf.groupby("feature")
            .agg(n=("lift_emp", "count"), mean_lift=("lift_emp", "mean"),
                 sd=("lift_emp", "std"), mean_auprc=("auprc", "mean"))
            .sort_values("mean_lift", ascending=False))
    print(summ.head(12).to_string())
    summ.to_csv(C.RESULTS / "feature_summary.csv")

    print("\n" + "-" * 68 + "\nCOMPOSITION SENSITIVITY\n" + "-" * 68)
    print("corr_auprc_prevalence = naive baseline (performance tracking cohort)")
    cs = E.composition_sensitivity(perf, coh)
    if len(cs):
        print(cs.head(12).to_string(index=False))
        cs.to_csv(C.RESULTS / "composition_sensitivity.csv", index=False)

    print("\n" + "-" * 68 + "\nOUTCOME-STRATIFIED (pre-declared: free > poor)\n" + "-" * 68)
    os_ = E.outcome_stratified(perf, coh)
    if len(os_):
        print(os_.head(12).to_string(index=False))
        os_.to_csv(C.RESULTS / "outcome_stratified.csv", index=False)

    print("\n" + "-" * 68 + "\nRANKING: NAIVE vs CORRECTED\n" + "-" * 68)
    rk = E.ranking_comparison(perf, coh)
    print(rk.head(12).to_string())
    rk.to_csv(C.RESULTS / "ranking_comparison.csv")
    print(f"\nfeatures whose rank shifts by >=2: {(rk['shift'].abs() >= 2).sum()}")

    make_figures(coh, perf)
    print(f"\nAll outputs -> {C.RESULTS}")


# ================================================================== figures
def make_figures(coh: pd.DataFrame, perf: pd.DataFrame | None = None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    u = coh[coh.usable].copy()
    u["prev%"] = 100 * u["prevalence"]

    # ---- Figure 1: the paradox
    fig, ax = plt.subplots(1, 3, figsize=(13, 4.2))
    for a, (grp, title) in zip(ax[:2], [
            ("implant", "Marginal: by implant"),
            ("therapy", "By therapy")]):
        cats = [c for c in u[grp].dropna().unique()]
        data = [u.loc[u[grp] == c, "prev%"].dropna() for c in cats]
        a.boxplot(data, tick_labels=cats, showfliers=False)
        for i, d in enumerate(data):
            a.scatter(np.random.normal(i + 1, .05, len(d)), d, s=14, alpha=.6)
        a.set_title(title); a.set_ylabel("prevalence (%)")

    r = u[u.therapy == "RESECTION"]
    cats = [c for c in r["implant"].dropna().unique()]
    data = [r.loc[r["implant"] == c, "prev%"].dropna() for c in cats]
    ax[2].boxplot(data, tick_labels=cats, showfliers=False)
    for i, d in enumerate(data):
        ax[2].scatter(np.random.normal(i + 1, .05, len(d)), d, s=14, alpha=.6)
    ax[2].set_title("Within RESECTION only\n(confound removed)")
    ax[2].set_ylabel("prevalence (%)")
    fig.suptitle("Figure 1 - Apparent implant effect is explained by therapy",
                 fontweight="bold")
    fig.tight_layout()
    fig.savefig(C.RESULTS / "fig1_paradox.png", dpi=160)
    plt.close(fig)

    # ---- Figure 2: prevalence landscape
    fig, ax = plt.subplots(figsize=(9, 4))
    for i, (ds, g) in enumerate(u.groupby("dataset")):
        ax.scatter(np.random.normal(i, .07, len(g)), 100 * g["prevalence"],
                   s=26, alpha=.7, label=ds)
    ax.set_xticks(range(u["dataset"].nunique()))
    ax.set_xticklabels(sorted(u["dataset"].unique()))
    ax.set_ylabel("prevalence (%)")
    ax.set_title("Figure 2 - Cohort composition differs between datasets")
    ax.legend()
    fig.tight_layout(); fig.savefig(C.RESULTS / "fig2_prevalence.png", dpi=160)
    plt.close(fig)

    if perf is None or not len(perf):
        return

    # ---- Figure 3: outcome-stratified lift for the best feature
    best = perf.groupby("feature")["lift_emp"].mean().idxmax()
    g = perf[perf.feature == best].join(
        coh.set_index("sub")["seizure_free"], on="sub")
    a = g.loc[g.seizure_free == True, "lift_emp"].dropna()
    b = g.loc[g.seizure_free == False, "lift_emp"].dropna()
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ax.boxplot([a, b], tick_labels=[f"Engel 1\n(n={len(a)})",
                               f"Engel 2+\n(n={len(b)})"], showfliers=False)
    for i, d in enumerate([a, b]):
        ax.scatter(np.random.normal(i + 1, .05, len(d)), d, s=22, alpha=.7)
    ax.axhline(1.0, ls="--", c="grey", lw=1)
    ax.set_ylabel("lift (AUPRC / empirical null)")
    ax.set_title(f"Figure 3 - Outcome-stratified\n{best}")
    fig.tight_layout(); fig.savefig(C.RESULTS / "fig3_outcome.png", dpi=160)
    plt.close(fig)
    print("figures written")


# ================================================================== main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="all",
                    choices=["cohort", "features", "evaluate", "all"])
    ap.add_argument("--datasets", nargs="+", default=["ds003876", "ds004100"])
    ap.add_argument("--families", nargs="+", default=None,
                    help="subset of: spectral graph ssi fragility")
    ap.add_argument("--limit", type=int, default=None,
                    help="process only the first N patients (smoke test)")
    ap.add_argument("--debug", action="store_true")
    a = ap.parse_args()

    warnings.filterwarnings("ignore", category=RuntimeWarning)
    C.ensure_dirs()

    coh = None
    if a.stage in ("cohort", "all"):
        coh = stage_cohort(a.datasets)
    if coh is None:
        coh = pd.read_csv(C.RESULTS / "cohort.csv")

    if a.stage in ("features", "all"):
        stage_features(coh, a.families, a.limit)
    if a.stage in ("evaluate", "all"):
        stage_evaluate(coh)


if __name__ == "__main__":
    main()
