"""
Two analyses that lift the paper to (and past) the Hatano et al. standard.

A. COMPOSITION-ONLY PREDICTION  -- the headline
   Can we predict a patient's reported AUPRC from cohort composition alone,
   without touching the EEG? Cross-validated R^2 for AUPRC vs for lift.
   If AUPRC is predictable and lift is not, reported performance is largely
   a property of the cohort.

B. VARIANCE DECOMPOSITION -- the interpretability figure (their SHAP analogue)
   How much variance in reported performance does each composition factor
   explain, and how much survives normalisation?

Also: bootstrap CIs and leave-one-centre-out stability for the key correlations,
and a full Table 1 in the style of Hatano et al.
"""
import os, numpy as np, pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.metrics import r2_score

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = rf"{BASE}\results"
rng = np.random.default_rng(0)

perf = pd.read_csv(rf"{R}\per_patient_metrics.csv")
coh  = pd.read_csv(rf"{R}\cohort.csv")

part = []
for ds in ["ds003876", "ds004100"]:
    p = pd.read_csv(rf"{BASE}\raw\{ds}\participants.tsv", sep="\t")
    p.columns = [c.strip() for c in p.columns]
    p["sub"] = p[p.columns[0]].astype(str).str.strip()
    p["dataset"] = ds
    part.append(p)
part = pd.concat(part, ignore_index=True)

u = coh[coh.usable].merge(part, on=["sub", "dataset"], how="left", suffixes=("", "_p"))
u["centre"] = u["site"].fillna("HUP") if "site" in u else u["dataset"]
u["lesional"] = (u.get("lesion_status", pd.Series(index=u.index, dtype=object))
                 .astype(str).str.upper().eq("LESIONAL").astype(float))
u["is_temporal"] = (u.get("target", pd.Series(index=u.index, dtype=object))
                    .astype(str).str.upper().isin(["TEMPORAL", "MTL"]).astype(float))

D = perf.merge(u[["sub", "centre", "therapy", "implant", "lesional",
                  "is_temporal", "n_valid", "engel_num", "seizure_free"]],
               on="sub", how="left")

# =====================================================================
# A. COMPOSITION-ONLY PREDICTION OF REPORTED PERFORMANCE
# =====================================================================
print("=" * 70)
print("A. CAN COMPOSITION ALONE PREDICT REPORTED PERFORMANCE?")
print("   (inputs: prevalence, therapy, implant, centre, lesional, target,")
print("    channel count -- NO EEG SIGNAL AT ALL)")
print("=" * 70)

COMP = ["prevalence", "is_resection", "is_ecog", "lesional",
        "is_temporal", "n_valid"]

rows = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "lift_emp", "prevalence"]).copy()
    if len(g) < 30:
        continue
    g["is_resection"] = (g.therapy == "RESECTION").astype(float)
    g["is_ecog"] = (g.implant == "ECOG").astype(float)
    X = g[COMP].fillna(0).to_numpy()
    groups = g.centre.fillna("NA").to_numpy()
    n_groups = len(np.unique(groups))
    cv = GroupKFold(n_splits=min(4, n_groups)) if n_groups > 1 else 4

    out = {"feature": feat, "n": len(g)}
    for target in ["auprc", "lift_emp"]:
        y = g[target].to_numpy()
        m = RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                                  random_state=0, n_jobs=-1)
        try:
            pred = cross_val_predict(m, X, y, cv=cv, groups=groups)
        except Exception:
            pred = cross_val_predict(m, X, y, cv=4)
        out[f"R2_{target}"] = r2_score(y, pred)
    rows.append(out)

A = pd.DataFrame(rows).sort_values("R2_auprc", ascending=False)
A.round(3).to_csv(rf"{R}\TABLE_composition_only_prediction.csv", index=False)
print(A.round(3).head(15).to_string(index=False))
print(f"\nmedian R2 predicting raw AUPRC   : {A.R2_auprc.median():.3f}")
print(f"median R2 predicting lift        : {A.R2_lift_emp.median():.3f}")
print(f"features with R2(AUPRC) > 0.3    : {(A.R2_auprc > .3).sum()} / {len(A)}")
print(f"features with R2(lift)  > 0.3    : {(A.R2_lift_emp > .3).sum()} / {len(A)}")
print("\nINTERPRETATION: a high R2 for AUPRC with a low R2 for lift means")
print("reported performance is largely predictable from who is in the cohort.")

# =====================================================================
# B. VARIANCE DECOMPOSITION  (SHAP analogue)
# =====================================================================
print("\n" + "=" * 70)
print("B. VARIANCE IN REPORTED PERFORMANCE EXPLAINED BY EACH FACTOR")
print("=" * 70)

FACTORS = {
    "prevalence":   ["prevalence"],
    "therapy":      ["is_resection"],
    "implant":      ["is_ecog"],
    "lesional":     ["lesional"],
    "target":       ["is_temporal"],
    "array size":   ["n_valid"],
}

dec = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "prevalence"]).copy()
    if len(g) < 30:
        continue
    g["is_resection"] = (g.therapy == "RESECTION").astype(float)
    g["is_ecog"] = (g.implant == "ECOG").astype(float)
    for target in ["auprc", "lift_emp"]:
        y = g[target].to_numpy()
        row = {"feature": feat, "metric": target}
        for name, cols in FACTORS.items():
            X = g[cols].fillna(0).to_numpy()
            row[name] = max(0.0, r2_score(y, LinearRegression().fit(X, y).predict(X)))
        Xall = g[[c for cs in FACTORS.values() for c in cs]].fillna(0).to_numpy()
        row["all combined"] = max(0.0, r2_score(
            y, LinearRegression().fit(Xall, y).predict(Xall)))
        dec.append(row)

B = pd.DataFrame(dec)
B.round(3).to_csv(rf"{R}\TABLE_variance_decomposition.csv", index=False)
print("\nMedian R^2 across 28 features:\n")
print(B.groupby("metric")[list(FACTORS) + ["all combined"]]
       .median().round(3).T.to_string())

# =====================================================================
# C. BOOTSTRAP CI + LEAVE-ONE-CENTRE-OUT ON THE KEY CORRELATION
# =====================================================================
print("\n" + "=" * 70)
print("C. ROBUSTNESS OF corr(AUPRC, prevalence)")
print("=" * 70)

def boot_ci(x, y, n=2000):
    rs = []
    idx = np.arange(len(x))
    for _ in range(n):
        s = rng.choice(idx, len(idx), replace=True)
        if len(np.unique(y[s])) < 3:
            continue
        rs.append(stats.pearsonr(x[s], y[s])[0])
    return np.percentile(rs, [2.5, 97.5])

rows = []
for feat, g in D.groupby("feature"):
    g = g.dropna(subset=["auprc", "prevalence"])
    if len(g) < 30:
        continue
    x, y = g.prevalence.to_numpy(), g.auprc.to_numpy()
    r_, p_ = stats.pearsonr(x, y)
    lo, hi = boot_ci(x, y)
    # leave-one-centre-out
    loo = []
    for c in g.centre.dropna().unique():
        gg = g[g.centre != c]
        if len(gg) > 20:
            loo.append(stats.pearsonr(gg.prevalence, gg.auprc)[0])
    rows.append({"feature": feat, "r": r_, "ci_lo": lo, "ci_hi": hi,
                 "p": p_, "loco_min": min(loo) if loo else np.nan,
                 "loco_max": max(loo) if loo else np.nan})

C = pd.DataFrame(rows).sort_values("r", ascending=False)
C.round(3).to_csv(rf"{R}\TABLE_correlation_robustness.csv", index=False)
print(C.round(3).head(12).to_string(index=False))
print(f"\nall 28 CIs exclude zero: {(C.ci_lo > 0).all()}")
print(f"minimum leave-one-centre-out r across all features: {C.loco_min.min():.3f}")

# =====================================================================
# D. FULL TABLE 1  (Hatano-style participant profile)
# =====================================================================
print("\n" + "=" * 70)
print("D. TABLE 1 -- PARTICIPANT PROFILE")
print("=" * 70)

def profile(g, label):
    age = pd.to_numeric(g.get("age"), errors="coerce")
    sex = g.get("sex", pd.Series(dtype=object)).astype(str).str.upper()
    eng = pd.to_numeric(g.engel_num, errors="coerce")
    d = {
        "n": len(g),
        "Age, years": f"{age.mean():.1f}±{age.std():.1f}" if age.notna().any() else "—",
        "Sex, female n (%)": f"{(sex=='F').sum()} ({100*(sex=='F').mean():.0f}%)",
        "Resection, n (%)": f"{(g.therapy=='RESECTION').sum()} "
                            f"({100*(g.therapy=='RESECTION').mean():.0f}%)",
        "Ablation, n (%)": f"{(g.therapy=='ABLATION').sum()} "
                           f"({100*(g.therapy=='ABLATION').mean():.0f}%)",
        "ECoG / SEEG": f"{(g.implant=='ECOG').sum()} / {(g.implant=='SEEG').sum()}",
        "MRI lesional, n (%)": (f"{int(g.lesional.sum())} "
                                f"({100*g.lesional.mean():.0f}%)"
                                if g.lesional.notna().any() else "—"),
        "Analysable electrodes, total": int(g.n_valid.sum()),
        "Electrodes per patient": f"{g.n_valid.mean():.0f}±{g.n_valid.std():.0f}",
        "Treated-channel prevalence, median % ":
            f"{100*g.prevalence.median():.1f}",
        "Prevalence range, %": f"{100*g.prevalence.min():.1f}–"
                               f"{100*g.prevalence.max():.1f}",
    }
    for k in [1, 2, 3, 4]:
        d[f"Engel class {k}, n (%)"] = f"{(eng==k).sum()} ({100*(eng==k).mean():.0f}%)"
    return pd.Series(d, name=label)

cols = []
for c in ["HUP", "NIH", "UMF", "JHH", "JHU"]:
    g = u[u.centre == c]
    if len(g):
        cols.append(profile(g, c))
cols.append(profile(u, "Total"))
T1 = pd.concat(cols, axis=1)
T1.to_csv(rf"{R}\TABLE1_full.csv")
print(T1.to_string())
print(f"\nAll tables written to {R}")
