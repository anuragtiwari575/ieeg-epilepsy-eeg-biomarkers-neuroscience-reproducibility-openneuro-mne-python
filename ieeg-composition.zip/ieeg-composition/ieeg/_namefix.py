"""Channel-name normalisation between channels.tsv and the signal header.

EDF+ headers wrap and truncate channel names, and the two releases decorate them
differently:

    'EEG RAI1-G2'       -> RAI1
    'EEG POL LPFC1'     -> LPFC1     (doubled prefix)
    'EEG POL RATO1-Re'  -> RATO1     (truncated '-Ref')

Reconciling these is necessary to align labels with signals at all; without it
most participants fail to load. The caller must also guard against collisions,
since two distinct header names can normalise to the same string.
"""
import re

PREFIX = re.compile(r"^\s*(EEG|ECOG|SEEG|POL|IEEG|EDF|DC)\s+", re.I)
SUFFIX = re.compile(
    r"-\s*(REF|R|RE|G\d*|A\d+|AVG|AV|LE|RE[FR]?|COM|CAR|ORG)\s*$", re.I)


def norm(name: str) -> str:
    """Normalised form of a channel name."""
    s = str(name).strip()
    for _ in range(4):                      # prefixes can be doubled
        s2 = PREFIX.sub("", s)
        if s2 == s:
            break
        s = s2
    s = SUFFIX.sub("", s)
    return s.upper().replace(" ", "").replace("_", "")


def build_map(edf_names):
    """Map normalised name -> original header name. First occurrence wins."""
    out = {}
    for n in edf_names:
        out.setdefault(norm(n), n)
    return out
