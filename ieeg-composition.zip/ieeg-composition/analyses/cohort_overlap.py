"""
Two verifications requested by review.

V1  COHORT OVERLAP
    Does any of the 22 ds003876 participants used in the main analysis appear
    among the 79 released source-sink derivative files? The derivatives use a
    different subject numbering, so overlap must be assessed from channel-name
    sets. We report the best Jaccard overlap per participant so the claim of
    independence can be stated with the evidence behind it.

V2  DO THE FIVE SURVIVING FEATURES SURVIVE LOO ORIENTATION?
    The orientation sensitivity analysis was reported for the outcome test only.
    Here we repeat the localization test (bootstrap median lambda, BH-corrected)
    using leave-one-participant-out orientation.
"""
import os, glob, re
import numpy as np
import pandas as pd
from scipy.io import loadmat
from statsmodels.stats.multitest import multipletests

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
rng = np.random.default_rng(0)

# ══════════════════════════════════════════════════════════════════
# V1.  COHORT OVERLAP
# ══════════════════════════════════════════════════════════════════
print("=" * 74)
print("V1.  OVERLAP BETWEEN THE 22 ds003876 PARTICIPANTS AND THE 79 DERIVATIVES")
print("=" * 74)

refs = {}
for f in sorted(glob.glob(os.path.join(BASE, "raw", "ds003876", "derivatives",
                                       "**", "*_ss_ind.mat"), recursive=True)):
    try:
        d = loadmat(f)
        refs[os.path.basename(os.path.dirname(f))] = {
            str(x[0][0]).strip().upper() for x in d["labels"]}
    except Exception:
        pass

mine = {}
for f in glob.glob(os.path.join(BASE, "features", "ds003876_*.parquet")):
    sub = re.search(r"ds003876_(sub-\w+)", os.path.basename(f)).group(1)
    mine[sub] = set(pd.read_parquet(f)["channel"].astype(str).str.upper())

print(f"{len(refs)} derivative files, {len(mine)} analysed participants\n")
rows = []
for sub, ms in mine.items():
    best, bj = None, 0.0
    for rf, rs in refs.items():
        j = len(ms & rs) / max(len(ms | rs), 1)
        if j > bj:
            bj, best = j, rf
    rows.append({"participant": sub, "best_match": best,
                 "jaccard": round(bj, 3),
                 "shared_channels": len(ms & refs[best]) if best else 0,
                 "n_channels": len(ms)})
V = pd.DataFrame(rows).sort_values("jaccard", ascending=False)
V.to_csv(os.path.join(R, "TABLE_cohort_overlap.csv"), index=False)
print(V.head(8).to_string(index=False))
print(f"\nhighest Jaccard overlap with any derivative file : {V.jaccard.max():.3f}")
print(f"participants exceeding Jaccard 0.5               : {(V.jaccard > .5).sum()}")
print(f"participants exceeding Jaccard 0.2               : {(V.jaccard > .2).sum()}")
if V.jaccard.max() < 0.2:
    print("\n=> No participant plausibly appears in both sets.")
else:
    print("\n=> Possible overlap; wording must be changed.")

# ══════════════════════════════════════════════════════════════════
# V2.  LOCALIZATION UNDER LEAVE-ONE-PARTICIPANT-OUT ORIENTATION
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 74)
print("V2.  DO THE FIVE SURVIVING FEATURES SURVIVE LOO ORIENTATION?")
print("=" * 74)

O = pd.read_csv(os.path.join(R, "TABLE_orientation_sensitivity.csv"))
rows = []
for feat, g in O.groupby("feature"):
    v = g["lift_loo"].dropna().to_numpy()
    if len(v) < 20:
        continue
    meds = np.array([np.median(rng.choice(v, len(v), replace=True))
                     for _ in range(5000)])
    rows.append({"feature": feat, "median_lift_loo": float(np.median(v)),
                 "ci_lo": float(np.percentile(meds, 2.5)),
                 "ci_hi": float(np.percentile(meds, 97.5)),
                 "p_boot": float(np.mean(meds <= 1.0))})
L = pd.DataFrame(rows)
L["q_BH"] = multipletests(L.p_boot.clip(lower=1/5000), method="fdr_bh")[1]
L = L.sort_values("median_lift_loo", ascending=False)
L.round(4).to_csv(os.path.join(R, "TABLE_localization_LOO_orientation.csv"), index=False)

surv = L[(L.q_BH < .05) & (L.median_lift_loo > 1)]
print(L.head(10).round(4).to_string(index=False))
print(f"\nsurviving BH under LOO orientation: {len(surv)} of {len(L)}")
for _, r in surv.iterrows():
    print(f"  {r.feature:26s} median {r.median_lift_loo:.2f} "
          f"({r.ci_lo:.2f}-{r.ci_hi:.2f}), q = {r.q_BH:.4f}")

orig = ["spectral::rel_delta", "spectral::bp_delta", "spectral::bp_theta",
        "spectral::rel_alpha", "spectral::spec_entropy"]
same = set(surv.feature) == set(orig)
print(f"\nidentical to the pooled-orientation set of five: {same}")
if not same:
    print("  added  :", sorted(set(surv.feature) - set(orig)))
    print("  dropped:", sorted(set(orig) - set(surv.feature)))

print("\nTables written to", R)
