#!/usr/bin/env python3
"""Single entry point for the whole analysis.

    python run.py --list            what each stage does and its state
    python run.py --stage all       reproduce everything, in dependency order
    python run.py --stage features  one stage
    python run.py --manifest        where every reported number comes from

Stages declare what they produce and what they require, so a stage cannot run
before its inputs exist. Stages already complete are skipped unless --force.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(os.environ.get("IEEG_BASE",
                           r"C:\Users\Anurag Tiwari\ieeg_project"))
CODE = Path(__file__).resolve().parent
RESULTS = BASE / "results"
FEATURES = BASE / "features"

# name: (command, produces, requires, description)
STAGES = {
    "cohort": (
        "run_pipeline.py --stage cohort",
        ["cohort.csv", "confound_tests.csv"], [],
        "Build the cohort from both releases."),

    "features": (
        "run_pipeline.py --stage features",
        ["<features>"], ["cohort.csv"],
        "Preprocess and compute 28 per-channel features. Checkpointed; ~2 h."),

    "metrics": (
        "run_pipeline.py --stage evaluate",
        ["per_patient_metrics.csv", "permutation_controls.csv",
         "outcome_stratified.csv"], ["<features>"],
        "Per-participant metrics, empirical null, permutation control."),

    "orientation": (
        "analyses/orientation.py",
        ["per_patient_metrics_loo.csv", "orientation_comparison.txt"],
        ["per_patient_metrics.csv"],
        "Leave-one-participant-out orientation, the primary protocol."),

    "composition": (
        "analyses/composition_and_variance.py",
        ["TABLE_correlation_robustness.csv",
         "TABLE_variance_decomposition.csv"],
        ["per_patient_metrics.csv"],
        "Correlation robustness and variance decomposition."),

    "composition_n": (
        "analyses/composition_effective_n.py",
        ["TABLE_composition_primary_n77.csv"],
        ["per_patient_metrics.csv"],
        "Composition model with covariates correctly restricted."),

    "localization": (
        "analyses/localization_evidence.py",
        ["TABLE_localization_evidence_BH.csv"],
        ["per_patient_metrics.csv"],
        "Which features exceed the empirical null after correction."),

    "spatial": (
        "analyses/spatial_null.py",
        ["TABLE_spatial_null_evidence.csv"], ["<features>"],
        "The same under a null preserving the spatial structure of the "
        "treated region."),

    "soz": (
        "analyses/soz_label.py",
        ["TABLE_soz_evidence_iid.csv"], ["<features>"],
        "All three analyses repeated with the onset zone as the label."),

    "robustness": (
        "analyses/robustness.py",
        ["TABLE_model_sensitivity.csv", "TABLE_lift_bootstrap_ci.csv"],
        ["per_patient_metrics.csv"],
        "Learners, bootstrap intervals, leave-one-dataset-out."),

    "ssi_lambda": (
        "analyses/ssi_regularisation.py",
        ["TABLE_ssi_regularisation_sensitivity.csv"], ["cohort.csv"],
        "Source--sink at the published regularisation."),

    "simulation": (
        "analyses/simulation.py",
        ["TABLE_simulation.csv", "FIG5_controls.pdf"],
        ["permutation_controls.csv"],
        "Fixed-ranking-quality simulation, and Figure 5."),

    "below_null": (
        "analyses/below_null_check.py",
        ["TABLE_below_null_simulation.csv"],
        ["reference_ssi_validation.csv"],
        "Below-null fraction against prevalence at fixed ranking quality."),

    "logistic": (
        "analyses/logistic_outcome.py",
        ["TABLE_logistic_outcome_all.csv"], ["per_patient_metrics.csv"],
        "Logistic sensitivity for the outcome result, and power."),

    "per_centre": (
        "analyses/per_centre_stats.py", [], ["per_patient_metrics.csv"],
        "Per-centre confound and covariate effects."),

    "overlap": (
        "analyses/cohort_overlap.py", ["TABLE_cohort_overlap.csv"], [],
        "Overlap between the analysed cohort and the released derivatives."),

    # figures: order matters, later scripts correct earlier output
    "figures": (
        None,
        ["FIG1_simpsons_paradox.pdf", "FIG2_composition_prediction.pdf",
         "FIG3_reference_validation.pdf", "FIG4_outcome_stratified.pdf"],
        ["per_patient_metrics.csv", "TABLE_composition_primary_n77.csv"],
        "All manuscript figures, in the order that later corrections apply."),

    "supplementary": (
        "analyses/build_supplementary.py", ["<supplementary>"],
        ["TABLE_localization_evidence_BH.csv"],
        "Assemble Supplementary Tables S1--S11."),

    "verify": (
        "analyses/consistency_check.py", [], ["per_patient_metrics.csv"],
        "Cross-check the manuscript against the outputs."),
}

FIGURE_ORDER = [
    "analyses/figures_1_3_4.py",       # base versions of Figs 1, 3, 4
    "analyses/figure3.py",             # Fig 3 with annotated-zone labels
    "analyses/table3_and_figure2.py",  # Fig 2 from the corrected model
    "analyses/figure1_cohort.py",      # Fig 1 from the final cohort
]

ORDER = ["cohort", "features", "metrics", "orientation", "composition",
         "composition_n", "localization", "spatial", "soz", "robustness",
         "ssi_lambda", "simulation", "below_null", "logistic", "per_centre",
         "overlap", "figures", "supplementary", "verify"]

MANIFEST = [
    ("Table 1, participant profile", "cohort.csv", "group by centre"),
    ("Fig 1 / 3.2, Simpson's paradox (0.021, 9.8e-5, 0.458)",
     "confound_tests.csv", "or rerun analyses/figure1_cohort.py"),
    ("3.3, ds003876 electrode effect (p = 0.002)",
     "confound_tests.csv", "cohort stage with --datasets ds003876"),
    ("3.4 / Fig 5C, temporal stability", "TABLE3_stability.csv", "column median"),
    ("3.6 / Table 2, five features surviving correction",
     "TABLE_localization_evidence_BH.csv", "q_boot_BH < .05 and median_lift > 1"),
    ("3.6, none surviving the spatial null",
     "TABLE_spatial_null_evidence.csv", "same columns"),
    ("3.6 / Fig 2A, corr(AP, prevalence) 0.53-0.88",
     "TABLE_correlation_robustness.csv", "r, ci_lo, ci_hi, loco_min"),
    ("3.7 / Fig 2B / Table 3, composition-only R^2",
     "TABLE_composition_primary_n77.csv", "rf_auprc, rf_lift_emp"),
    ("3.7, secondary model (n = 54)",
     "TABLE_composition_secondary_n55.csv", "same columns"),
    ("Fig 2C, variance decomposition (0.47 vs 0.01)",
     "TABLE_variance_decomposition.csv", "group by metric, medians"),
    ("3.8 / Fig 3, released outputs (0.43 / -0.06, 38% below null)",
     "reference_ssi_validation.csv", "prev, auprc, lift_emp"),
    ("3.8, below-null fraction is a skew artefact",
     "TABLE_below_null_simulation.csv", "frac_below_1 by auc_set"),
    ("3.9 / Table 4 / Fig 4, outcome null", "outcome_stratified.csv", ""),
    ("3.9, logistic sensitivity and power",
     "TABLE_logistic_outcome_all.csv", "and _resection.csv"),
    ("3.10, onset zone as the label",
     "TABLE_soz_evidence_iid.csv", "and _spatial.csv, TABLE_soz_correlation.csv"),
    ("3.9, orientation sensitivity", "TABLE_orientation_sensitivity.csv", ""),
    ("3.9, source-sink regularisation (93.7% unstable)",
     "TABLE_ssi_regularisation_sensitivity.csv", "column frac_unstable"),
    ("3.5 / Fig 5D, simulation", "TABLE_simulation.csv", "group by auc_set"),
    ("Fig 5A, permutation control (0.9996)",
     "permutation_controls.csv", "column perm_mean_lift"),
]


def have(name: str) -> bool:
    if name.startswith("<"):
        if "features" in name:
            return FEATURES.exists() and any(FEATURES.glob("*.parquet"))
        if "supplementary" in name:
            return (BASE / "supplementary").exists()
        return True
    return (RESULTS / name).exists()


def state(stage: str) -> str:
    _, produces, _, _ = STAGES[stage]
    if not produces:
        return "no output"
    done = sum(have(f) for f in produces)
    if done == len(produces):
        return "done"
    return f"partial ({done}/{len(produces)})" if done else "pending"


def show_list() -> None:
    print(f"{'stage':<16}{'state':<18}outputs")
    print("-" * 78)
    for st in ORDER:
        _, produces, _, desc = STAGES[st]
        print(f"{st:<16}{state(st):<18}{', '.join(produces)[:42]}")
        print(f"{'':<34}{desc}")
    print(f"\nBASE = {BASE}")


def show_manifest() -> None:
    print("Every reported number, and the file it comes from.\n")
    print(f"{'claim':<56}{'file':<44}note")
    print("-" * 132)
    for claim, f, note in MANIFEST:
        print(f"{' ' if have(f) else '!'}{claim:<55}{f:<44}{note}")
    print("\n!  output not present; run the stage that produces it")


def _run(script: str, extra: str = "") -> bool:
    parts = script.split()
    path = CODE / parts[0]
    if not path.exists():
        print(f"  script not found: {path}")
        return False
    cmd = [sys.executable, "-u", str(path)] + parts[1:] + (
        extra.split() if extra else [])
    env = dict(os.environ, IEEG_BASE=str(BASE), PYTHONHASHSEED="0")
    return subprocess.run(cmd, env=env, cwd=str(CODE)).returncode == 0


def run_stage(stage: str, extra: str = "") -> bool:
    script, produces, requires, desc = STAGES[stage]
    for r in requires:
        if not have(r):
            print(f"  SKIP  {stage}: requires {r}, which is missing")
            return False

    print(f"\n{'=' * 74}\n{stage.upper()}  --  {desc}\n{'=' * 74}")
    t0 = time.time()
    if stage == "figures":
        ok = all(_run(s) for s in FIGURE_ORDER)
    else:
        ok = _run(script, extra)
    print(f"\n  {'ok' if ok else 'FAILED'}  ({(time.time()-t0)/60:.1f} min)  "
          f"state now: {state(stage)}")
    return ok


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default=None, choices=list(STAGES) + ["all"])
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--manifest", action="store_true")
    ap.add_argument("--force", action="store_true",
                    help="re-run stages already marked done")
    ap.add_argument("--extra", default="",
                    help="arguments passed through to the stage script")
    a = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    FEATURES.mkdir(parents=True, exist_ok=True)

    if a.manifest:
        show_manifest(); return
    if a.list or not a.stage:
        show_list(); return

    todo = ORDER if a.stage == "all" else [a.stage]
    t0 = time.time()
    for st in todo:
        if not a.force and a.stage == "all" and state(st) == "done":
            print(f"  skip  {st}: already complete")
            continue
        run_stage(st, a.extra)
    print(f"\ntotal {(time.time() - t0) / 60:.1f} min\n\nstate:")
    for st in ORDER:
        print(f"  {st:<16}{state(st)}")


if __name__ == "__main__":
    main()
