"""
Two analyses closing the remaining statistical gap.

A. MULTIPLICITY-CORRECTED LOCALIZATION EVIDENCE
   The claim "six features localized robustly above chance" rested on
   uncorrected 95% bootstrap intervals. With 28 simultaneous tests at
   alpha = 0.05, roughly 1.4 false positives are expected. Here we compute a
   one-sided Wilcoxon signed-rank test of lambda against unity for every
   feature, apply Benjamini-Hochberg correction, and report raw p and
   adjusted q alongside the bootstrap interval.

B. DOES NORMALISATION REORDER THE FEATURES?
   If the features that survive normalisation are not the ones with the
   highest raw average precision, then raw performance ranking is not a guide
   to localization evidence -- a stronger conceptual point than the confound
   alone.
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
rng = np.random.default_rng(0)

perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))

# ══════════════════════════════════════════════════════════════════
# A.  IS lambda > 1, AFTER CORRECTING FOR 28 TESTS?
# ══════════════════════════════════════════════════════════════════
rows = []
for feat, g in perf.groupby("feature"):
    v = g["lift_emp"].dropna().to_numpy()
    if len(v) < 20:
        continue
    # one-sided Wilcoxon signed-rank against the null value of 1
    try:
        st, p_one = stats.wilcoxon(v - 1.0, alternative="greater")
    except ValueError:
        p_one = np.nan
    meds = np.array([np.median(rng.choice(v, len(v), replace=True))
                     for _ in range(5000)])
    rows.append({
        "feature": feat, "n": len(v),
        "median_lift": float(np.median(v)),
        "mean_lift": float(np.mean(v)),
        "ci_lo": float(np.percentile(meds, 2.5)),
        "ci_hi": float(np.percentile(meds, 97.5)),
        "p_raw": float(p_one),
        # bootstrap one-sided p as a check on the signed-rank test
        "p_boot": float(np.mean(meds <= 1.0)),
    })

A = pd.DataFrame(rows)
ok = A.p_raw.notna()
A.loc[ok, "q_BH"] = multipletests(A.loc[ok, "p_raw"], method="fdr_bh")[1]
A = A.sort_values("median_lift", ascending=False)
A.round(4).to_csv(os.path.join(R, "TABLE_localization_evidence_BH.csv"), index=False)

n_ci = int((A.ci_lo > 1).sum())
n_raw = int((A.p_raw < .05).sum())
n_bh = int((A.q_BH < .05).sum())

print("=" * 74)
print("A.  LOCALIZATION EVIDENCE WITH MULTIPLICITY CORRECTION")
print("=" * 74)
print(A[["feature", "n", "median_lift", "ci_lo", "ci_hi",
         "p_raw", "q_BH"]].round(4).to_string(index=False))
print(f"\nuncorrected bootstrap CI excludes 1 : {n_ci} of {len(A)}")
print(f"raw p < 0.05                        : {n_raw} of {len(A)}")
print(f"BH-adjusted q < 0.05                : {n_bh} of {len(A)}   <-- report this")
if n_bh:
    print("\nSurvive correction:")
    for _, r in A[A.q_BH < .05].iterrows():
        print(f"  {r.feature:26s} median {r.median_lift:.2f} "
              f"(95% CI {r.ci_lo:.2f}-{r.ci_hi:.2f}), q = {r.q_BH:.4f}")

# ══════════════════════════════════════════════════════════════════
# B.  DOES NORMALISATION REORDER THE FEATURES?
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 74)
print("B.  RAW PERFORMANCE RANKING vs LOCALIZATION EVIDENCE")
print("=" * 74)

summ = (perf.groupby("feature")
        .agg(mean_ap=("auprc", "mean"), median_lift=("lift_emp", "median"))
        .join(A.set_index("feature")[["q_BH"]]))
summ["rank_ap"] = summ.mean_ap.rank(ascending=False)
summ["rank_lift"] = summ.median_lift.rank(ascending=False)
summ["shift"] = summ.rank_ap - summ.rank_lift
summ = summ.sort_values("rank_lift")
summ.round(3).to_csv(os.path.join(R, "TABLE_rank_shift.csv"))

rho, p_rho = stats.spearmanr(summ.mean_ap, summ.median_lift)
print(f"Spearman between mean AP and median lambda : rho = {rho:.3f}, p = {p_rho:.3g}")
print(f"features shifting >= 5 rank positions      : {(summ['shift'].abs() >= 5).sum()} of {len(summ)}")
print(f"maximum rank shift                         : {int(summ['shift'].abs().max())}")

print("\nTop 5 by raw average precision:")
for f, r in summ.sort_values("rank_ap").head(5).iterrows():
    q = r.q_BH
    tag = "survives BH" if (q == q and q < .05) else "not significant"
    print(f"  AP rank {int(r.rank_ap):2d} -> lambda rank {int(r.rank_lift):2d}  "
          f"{f:26s} {tag}")

print("\nTop 5 by normalised lift:")
for f, r in summ.head(5).iterrows():
    q = r.q_BH
    tag = "survives BH" if (q == q and q < .05) else "not significant"
    print(f"  AP rank {int(r.rank_ap):2d} -> lambda rank {int(r.rank_lift):2d}  "
          f"{f:26s} {tag}")

overlap = len(set(summ.sort_values("rank_ap").head(5).index) &
              set(summ.head(5).index))
print(f"\noverlap between the two top-5 sets: {overlap} of 5")
print("\nTables written to", R)
