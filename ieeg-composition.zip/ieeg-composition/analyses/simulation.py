"""
Simulation: average precision varies with prevalence at FIXED ranking quality.

Scores are drawn from a Gaussian shift model in which the separation between
treated and untreated channels is set analytically:

    untreated ~ N(0, 1),  treated ~ N(d, 1),  AUC = Phi(d / sqrt(2))

so d = sqrt(2) * Phi^-1(AUC) fixes the ranking quality exactly. Prevalence is
then varied while d is held constant. If average precision moves while AUC does
not, the movement is a property of the cohort, not of the ranking.

Rebuilds Figure 5 as a 2x2 panel with the simulation added.
"""
import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score, roc_auc_score

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
rng = np.random.default_rng(0)

mpl.rcParams.update({
    "font.size": 8, "font.family": "serif", "axes.linewidth": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.dpi": 300,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 6.8,
})
BLUE, GREEN, RED, GREY, ORNG = "#2a6fb5", "#1a9e6e", "#c33", "#7a7a7a", "#e07b39"
GRID = "#e3e3dd"


def panel(ax, letter):
    ax.text(-0.17, 1.06, letter, transform=ax.transAxes,
            fontsize=10, fontweight="bold", va="bottom", ha="left")


# ══════════════════════════════════════════════════════════════════
# SIMULATION
# ══════════════════════════════════════════════════════════════════
N = 120                      # channels per simulated participant
REPS = 400
AUCS = [0.50, 0.60, 0.70, 0.80]
PREVS = [0.01, 0.02, 0.05, 0.10, 0.20, 0.35, 0.50]

rows = []
for auc_target in AUCS:
    d = np.sqrt(2) * stats.norm.ppf(auc_target)
    for pi in PREVS:
        npos = max(2, int(round(pi * N)))
        ap, au, lam = [], [], []
        # empirical null for this label vector
        y = np.zeros(N, bool); y[:npos] = True
        null = np.mean([average_precision_score(y, rng.random(N))
                        for _ in range(300)])
        for _ in range(REPS):
            s = rng.normal(0, 1, N)
            s[y] += d
            ap.append(average_precision_score(y, s))
            au.append(roc_auc_score(y, s))
            lam.append(ap[-1] / null)
        rows.append({"auc_set": auc_target, "prevalence": npos / N,
                     "AP": np.mean(ap), "AUC": np.mean(au),
                     "lift": np.mean(lam), "null": null})

S = pd.DataFrame(rows)
S.round(4).to_csv(os.path.join(R, "TABLE_simulation.csv"), index=False)

print("=" * 74)
print("SIMULATION: ranking quality fixed, prevalence varied")
print("=" * 74)
for a in AUCS:
    g = S[S.auc_set == a]
    print(f"\nAUC set to {a:.2f}   (realised {g.AUC.mean():.3f} "
          f"± {g.AUC.std():.3f} across prevalences)")
    print(f"  AP   ranges {g.AP.min():.3f} -> {g.AP.max():.3f}  "
          f"({g.AP.max()/max(g.AP.min(),1e-9):.1f}-fold)")
    print(f"  lift ranges {g.lift.min():.3f} -> {g.lift.max():.3f}  "
          f"({g.lift.max()/max(g.lift.min(),1e-9):.1f}-fold)")

g = S[S.auc_set == 0.70]
print(f"\nHeadline: at a fixed AUC of 0.70, average precision rises "
      f"{g.AP.max()/g.AP.min():.0f}-fold ({g.AP.min():.3f} to {g.AP.max():.3f})")
print(f"as prevalence goes from 1% to 50%, while lift varies only "
      f"{g.lift.max()/g.lift.min():.2f}-fold.")


# ══════════════════════════════════════════════════════════════════
# FIGURE 5  (2 x 2, simulation added as panel D)
# ══════════════════════════════════════════════════════════════════
ctrl = pd.read_csv(os.path.join(R, "permutation_controls.csv"))
stab_p = os.path.join(R, "TABLE3_stability.csv")

fig, axes = plt.subplots(2, 2, figsize=(7.1, 5.4))
ax = axes.ravel()

# A. permutation control
ax[0].hist(ctrl.perm_mean_lift, bins=14, color=BLUE, alpha=.85, zorder=3)
ax[0].axvline(1.0, color=RED, ls="--", lw=1.2, zorder=4)
ax[0].set_xlabel(r"mean $\lambda$ under label permutation")
ax[0].set_ylabel("number of features")
ax[0].set_ylim(0, ax[0].get_ylim()[1] * 1.30)
ax[0].text(.03, .94, f"mean = {ctrl.perm_mean_lift.mean():.3f}\n0 of 28 fail",
           transform=ax[0].transAxes, ha="left", va="top", fontsize=6.8)
ax[0].set_title("Permutation control", loc="left", fontsize=8.2, fontweight="bold")

# B. bias of the theoretical null
npos = np.arange(2, 31)
ratio = []
for k in npos:
    yv = np.zeros(120, bool); yv[:k] = True
    ratio.append(np.mean([average_precision_score(yv, rng.random(120))
                          for _ in range(200)]) / (k / 120))
ax[1].plot(npos, ratio, "-", color=BLUE, lw=1.7, zorder=3)
ax[1].axhline(1, color=RED, ls="--", lw=1.2, zorder=4)
ax[1].set_xlabel("treated channels $N_+$  (array of 120)")
ax[1].set_ylabel(r"$\mathrm{AP}_0 \,/\, \pi$")
ax[1].set_ylim(0.9, max(ratio) * 1.20)
ax[1].text(.97, .94, "naive $AP/\\pi$ biased\nupward at small $N_+$",
           transform=ax[1].transAxes, ha="right", va="top", fontsize=6.8)
ax[1].set_title("Bias of the theoretical null", loc="left", fontsize=8.2,
                fontweight="bold")

# C. temporal stability
if os.path.exists(stab_p):
    St = pd.read_csv(stab_p)
    col = "median" if "median" in St.columns else St.columns[1]
    st = St.sort_values(col)
    ax[2].barh(np.arange(len(st)), st[col], color=GREEN, height=.78, zorder=3)
    ax[2].axvline(0.5, color=RED, ls="--", lw=1.2, zorder=4)
    ax[2].set_yticks([]); ax[2].set_xlim(0, 1.22)
    ax[2].set_xlabel(r"split-half Spearman $\rho$")
    ax[2].set_ylabel("28 features")
    ax[2].text(1.19, len(st) * .5, f"{(st[col] > .5).sum()} of {len(st)}\nabove 0.5",
               ha="right", va="center", fontsize=6.8)
ax[2].set_title("Temporal stability", loc="left", fontsize=8.2, fontweight="bold")

# D. simulation
cols = {0.50: GREY, 0.60: ORNG, 0.70: BLUE, 0.80: GREEN}
for a_ in AUCS:
    g = S[S.auc_set == a_]
    ax[3].plot(100 * g.prevalence, g.AP, "-o", ms=3, lw=1.4,
               color=cols[a_], zorder=3, label=f"AUC = {a_:.2f}")
    ax[3].plot(100 * g.prevalence, g.lift, "--", lw=1.1, color=cols[a_],
               alpha=.55, zorder=2)
ax[3].set_xscale("log")
ax[3].set_xlabel("treated-channel prevalence (%)")
ax[3].set_ylabel("metric value")
ax[3].legend(frameon=False, loc="upper left", ncol=2, fontsize=6.4)
ax[3].text(.97, .05, "solid: average precision\ndashed: normalised lift",
           transform=ax[3].transAxes, ha="right", va="bottom", fontsize=6.4)
ax[3].set_title("Simulation at fixed ranking quality", loc="left",
                fontsize=8.2, fontweight="bold")

for a_, l in zip(ax, "ABCD"):
    a_.grid(color=GRID, lw=.5, zorder=0); a_.set_axisbelow(True); panel(a_, l)
fig.tight_layout()
for e in ("png", "pdf"):
    fig.savefig(os.path.join(R, f"FIG5_controls.{e}"))
print("\nsaved: FIG5_controls (now 2x2 with the simulation)")
plt.close(fig)
