"""Correct per-centre and covariate statistics: one test per feature,
then aggregate. The earlier version pooled patient x feature rows,
inflating n by 28-fold."""
import pandas as pd, numpy as np
from scipy import stats

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = rf"{BASE}\results"

perf = pd.read_csv(rf"{R}\per_patient_metrics.csv")
coh  = pd.read_csv(rf"{R}\cohort.csv")

part = []
for ds in ["ds003876", "ds004100"]:
    p = pd.read_csv(rf"{BASE}\raw\{ds}\participants.tsv", sep="\t")
    p.columns = [c.strip() for c in p.columns]
    p["sub"] = p[p.columns[0]].astype(str).str.strip()
    p["dataset"] = ds
    part.append(p)
part = pd.concat(part, ignore_index=True)

u = coh[coh.usable].merge(part, on=["sub", "dataset"], how="left", suffixes=("", "_p"))
u["centre"] = u["site"].fillna("HUP") if "site" in u else u["dataset"]

# ---- per-centre: one correlation per feature, then median across features
print("=== PER-CENTRE CONFOUND (per-feature, then aggregated) ===")
pm = perf.merge(u[["sub", "centre"]], on="sub", how="left")
rows = []
for c, g in pm.groupby("centre"):
    if g["sub"].nunique() < 10:
        continue
    rs, ps = [], []
    for f, gf in g.groupby("feature"):
        gf = gf.dropna(subset=["auprc", "prevalence"])
        if len(gf) < 8:
            continue
        r_, p_ = stats.pearsonr(gf.auprc, gf.prevalence)
        rs.append(r_); ps.append(p_)
    rows.append({"centre": c, "n_patients": g["sub"].nunique(),
                 "n_features": len(rs),
                 "median_r": round(np.median(rs), 3),
                 "IQR": f"{np.percentile(rs,25):.2f}-{np.percentile(rs,75):.2f}",
                 "features_p<0.05": int(np.sum(np.array(ps) < .05))})
print(pd.DataFrame(rows).to_string(index=False))

# ---- covariates: one Kruskal-Wallis per feature, count significant
print("\n=== COVARIATE EFFECTS ON LIFT (per-feature tests) ===")
h = u[u.dataset == "ds004100"]
for var in ["lesion_status", "target"]:
    if var not in h.columns:
        continue
    sub = perf.merge(h[["sub", var]], on="sub").dropna(subset=["lift_emp", var])
    sig = 0; tot = 0
    for f, gf in sub.groupby("feature"):
        grp = [x.lift_emp.values for _, x in gf.groupby(var) if len(x) >= 5]
        if len(grp) < 2:
            continue
        tot += 1
        if stats.kruskal(*grp).pvalue < .05:
            sig += 1
    print(f"{var:15s}: {sig}/{tot} features show a significant effect on lift")
    print(h.groupby(var)["prevalence"].agg(
        n="count", median=lambda x: round(100 * x.median(), 1)).to_string(), "\n")
