"""
A7. Is "55% of small-target participants fall below the empirical null" a real
    effect, or an artefact of the skew of lambda at small positive counts?

THE CONCERN
    lambda = AP / AP_0 is right-skewed: bounded below at zero, unbounded above.
    Its median therefore sits below its mean, and at small N_+ the skew is
    severe. A cohort with genuine, constant ranking ability could still show
    more than half its small-target participants below lambda = 1 purely from
    that asymmetry. If so, the paper's headline clinical claim is a property of
    the metric, not of the biomarker.

THE TEST
    Simulate participants at a FIXED, known ranking quality across the observed
    range of prevalence, and record the fraction falling below lambda = 1 at
    each. If that fraction is near 50% at small prevalence even at AUC = 0.65,
    the observed 55% carries little information; if it stays near zero while the
    observed value is 55%, the effect is real.

    We also replace the post-hoc 6% dichotomy with a continuous logistic
    regression of the below-null indicator on prevalence in the real data.
"""
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import average_precision_score, roc_auc_score
import statsmodels.api as sm

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")
rng = np.random.default_rng(0)

N_CH = 120
REPS = 500
AUCS = [0.50, 0.60, 0.65, 0.70, 0.80]
PREVS = [0.015, 0.02, 0.03, 0.04, 0.06, 0.08, 0.12, 0.20, 0.30, 0.40]

print("=" * 76)
print("A7.  FRACTION BELOW THE EMPIRICAL NULL AT FIXED RANKING QUALITY")
print("=" * 76)

rows = []
for auc in AUCS:
    d = np.sqrt(2) * stats.norm.ppf(auc)
    for pi in PREVS:
        npos = max(2, int(round(pi * N_CH)))
        y = np.zeros(N_CH, bool); y[:npos] = True
        null = np.mean([average_precision_score(y, rng.random(N_CH))
                        for _ in range(400)])
        lam, au = [], []
        for _ in range(REPS):
            s = rng.normal(0, 1, N_CH)
            s[y] += d
            lam.append(average_precision_score(y, s) / null)
            au.append(roc_auc_score(y, s))
        lam = np.asarray(lam)
        rows.append({"auc_set": auc, "auc_realised": float(np.mean(au)),
                     "prevalence": npos / N_CH, "n_pos": npos,
                     "median_lift": float(np.median(lam)),
                     "mean_lift": float(np.mean(lam)),
                     "frac_below_1": float(np.mean(lam < 1)),
                     "skewness": float(stats.skew(lam))})

S = pd.DataFrame(rows)
S.round(4).to_csv(os.path.join(R, "TABLE_below_null_simulation.csv"), index=False)

print(f"\n{'AUC':>6}{'prev':>8}{'N+':>5}{'median lift':>13}"
      f"{'mean lift':>11}{'% below 1':>11}{'skew':>8}")
for auc in AUCS:
    for _, r in S[S.auc_set == auc].iterrows():
        pv, npv = 100 * r['prevalence'], int(r['n_pos'])
        md, mn = r['median_lift'], r['mean_lift']
        fb, sk = 100 * r['frac_below_1'], r['skewness']
        print(f"{auc:6.2f}{pv:7.1f}%{npv:5d}{md:13.2f}{mn:11.2f}"
              f"{fb:10.0f}%{sk:8.2f}")
    print()

print("Observed in the released outputs:")
print("   prevalence < 6%   : 55% below the null")
print("   prevalence >= 6%  : 26% below the null\n")

lo = S[(S.prevalence < 0.06)]
hi = S[(S.prevalence >= 0.06)]
print("Simulated, for comparison:")
for auc in AUCS:
    a = lo[lo.auc_set == auc].frac_below_1.mean()
    b = hi[hi.auc_set == auc].frac_below_1.mean()
    print(f"   AUC {auc:.2f}:  < 6% -> {100*a:4.0f}% below,"
          f"   >= 6% -> {100*b:4.0f}% below")

print("\nINTERPRETATION")
print("  If the simulated fraction below 1 is already near 50% at small")
print("  prevalence for a ranking that is genuinely informative, then the")
print("  observed 55% says little and the claim must be withdrawn or")
print("  reframed. If the simulated fraction stays low, the effect is real.")

# ══════════════════════════════════════════════════════════════════
# continuous model on the real data, replacing the 6% dichotomy
# ══════════════════════════════════════════════════════════════════
print("\n" + "=" * 76)
print("CONTINUOUS MODEL ON THE RELEASED OUTPUTS (replaces the 6% split)")
print("=" * 76)

f = os.path.join(R, "reference_ssi_validation.csv")
if os.path.exists(f):
    r = pd.read_csv(f)
    r["below"] = (r.lift_emp < 1).astype(int)
    X = sm.add_constant(r[["prev"]])
    m = sm.Logit(r.below, X).fit(disp=0)
    print(m.summary2().tables[1].round(4).to_string())
    b, se = m.params["prev"], m.bse["prev"]
    print(f"\nodds ratio per 10 percentage points of prevalence: "
          f"{np.exp(10 * b / 100):.3f} "
          f"(95% CI {np.exp(10*(b-1.96*se)/100):.3f}-"
          f"{np.exp(10*(b+1.96*se)/100):.3f}), p = {m.pvalues['prev']:.4f}")

    # same thing for lambda itself, on the log scale
    lm = sm.OLS(np.log(r.lift_emp.clip(lower=1e-3)),
                sm.add_constant(r[["prev"]])).fit()
    print(f"\nlog-lambda on prevalence: beta = {lm.params['prev']:.3f}, "
          f"p = {lm.pvalues['prev']:.3f}  (a null slope means lambda is "
          f"prevalence-free)")
else:
    print("  reference_ssi_validation.csv not found")

# ══════════════════════════════════════════════════════════════════
# figure
# ══════════════════════════════════════════════════════════════════
mpl.rcParams.update({"font.size": 8, "font.family": "serif",
                     "axes.linewidth": 0.7, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.bbox": "tight",
                     "savefig.dpi": 300})
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.9))
cols = dict(zip(AUCS, ["#7a7a7a", "#e07b39", "#2a6fb5", "#1a9e6e", "#7b3fa0"]))
for auc in AUCS:
    g = S[S.auc_set == auc]
    ax[0].plot(100 * g.prevalence, 100 * g.frac_below_1, "-o", ms=3, lw=1.4,
               color=cols[auc], label=f"AUC = {auc:.2f}")
    ax[1].plot(100 * g.prevalence, g.median_lift, "-o", ms=3, lw=1.4,
               color=cols[auc])
ax[0].axhline(55, ls="--", color="#c33", lw=1.2)
ax[0].text(1.7, 57, "observed, < 6%", color="#c33", fontsize=6.6)
ax[0].axhline(26, ls="--", color="#0f6e56", lw=1.2)
ax[0].text(20, 28, "observed, $\\geq$ 6%", color="#0f6e56", fontsize=6.6)
ax[0].set_xscale("log"); ax[0].set_xlabel("prevalence (%)")
ax[0].set_ylabel(r"% of participants with $\lambda < 1$")
ax[0].legend(frameon=False, fontsize=6.2, ncol=2)
ax[0].set_title("A.  Below-null fraction at fixed ranking quality",
                loc="left", fontsize=8.2, fontweight="bold")
ax[1].axhline(1, ls="--", color="#7a7a7a", lw=1.0)
ax[1].set_xscale("log"); ax[1].set_xlabel("prevalence (%)")
ax[1].set_ylabel(r"median $\lambda$")
ax[1].set_title("B.  Median lift at fixed ranking quality",
                loc="left", fontsize=8.2, fontweight="bold")
for a in ax:
    a.grid(color="#e3e3dd", lw=.5, zorder=0); a.set_axisbelow(True)
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(R, f"FIGS_below_null_check.{ext}"))
print(f"\nfigure written: FIGS_below_null_check  ({R})")
