"""
Assemble the supplementary materials package for submission.

Produces, in ieeg_project/supplementary/ :

    Supplementary_Material.xlsx   one workbook, a contents sheet plus S1-S8
    S1_...csv  ...  S8_...csv     the same tables as plain CSV
    README.txt                    what each table contains

Journals differ: some want a single workbook, some want individual files, some
want both. This produces both so nothing has to be rebuilt at submission time.

No formulas are written -- these are static analysis outputs -- so no
recalculation step is needed.
"""
import os
import shutil
import pandas as pd

try:
    from openpyxl.styles import Font, Alignment, PatternFill
    from openpyxl.utils import get_column_letter
    HAVE_OPENPYXL = True
except ImportError:
    HAVE_OPENPYXL = False

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")
OUT = os.path.join(BASE, "supplementary")
os.makedirs(OUT, exist_ok=True)

# Supplementary table -> (source CSV(s), title, description)
SPEC = {
    "S1": (["SUPP_TABLE1_all_features.csv"],
           "All 28 features, full statistics",
           "Mean lift, mean average precision, correlation of average precision "
           "with prevalence, partial correlation of lift with outcome, and the "
           "outcome-stratified test, for each of the 28 features."),

    "S2": (["TABLE3_stability.csv"],
           "Temporal stability",
           "Per-channel Spearman correlation between features recomputed on two "
           "disjoint halves of each recording, in 20 randomly selected "
           "participants. Median, interquartile range and the fraction of "
           "participants exceeding rho = 0.5, for each feature."),

    "S3": (["TABLE2_per_centre_confound.csv"],
           "Per-centre confound",
           "Correlation of average precision with prevalence computed separately "
           "within each contributing centre with at least ten participants, "
           "aggregated across the 28 features."),

    "S4": (["TABLE_composition_only_prediction.csv"],
           "Composition-only prediction, all features",
           "Cross-validated R-squared of a random-forest model given only "
           "composition variables, predicting average precision and normalised "
           "lift, under leave-one-centre-out grouping."),

    "S5": (["TABLE_localization_evidence_BH.csv"],
           "Localization evidence with multiplicity correction",
           "Median normalised lift with bootstrap 95% confidence interval, the "
           "one-sided bootstrap probability that the median does not exceed "
           "unity, and the Benjamini-Hochberg adjusted value, for all 28 "
           "features."),

    "S6": (["TABLE_orientation_sensitivity.csv", "TABLE_model_sensitivity.csv"],
           "Orientation and model-choice sensitivity",
           "Left: lift under pooled versus leave-one-participant-out feature "
           "orientation. Right: cross-validated R-squared under four learners "
           "(random forest, gradient boosting, ridge, ordinary least squares)."),

    "S7": (["TABLE_ssi_regularisation_sensitivity.csv"],
           "Source-sink regularisation sensitivity",
           "Per-participant fraction of windows unstable at the published "
           "lambda = 1e-4, per-channel Spearman agreement between the adaptive "
           "and fixed-regularisation source-sink features, and the resulting "
           "lift under each."),

    "S8": (["TABLE_composition_primary_n77.csv",
            "TABLE_composition_secondary_n55.csv"],
           "Composition model with restricted and extended covariates",
           "Primary model (n = 77) using only covariates observed in both "
           "cohorts. Secondary model (ds004100 only, n = 54) adding lesional "
           "status and surgical target."),
}


def load(names):
    frames = []
    for n in names:
        p = os.path.join(R, n)
        if os.path.exists(p):
            frames.append((n, pd.read_csv(p)))
    return frames


print("=" * 70)
print("ASSEMBLING SUPPLEMENTARY MATERIALS")
print("=" * 70)

collected, missing = {}, []
for tag, (srcs, title, desc) in SPEC.items():
    frames = load(srcs)
    if not frames:
        missing.append(f"{tag}: {', '.join(srcs)}")
        print(f"  {tag}  MISSING  ({', '.join(srcs)})")
        continue
    if len(frames) == 1:
        df = frames[0][1]
    else:
        # two related tables side by side, separated by a blank column
        a, b = frames[0][1], frames[1][1]
        a = a.add_prefix(f"[{frames[0][0].replace('.csv','')}] ")
        b = b.add_prefix(f"[{frames[1][0].replace('.csv','')}] ")
        df = pd.concat([a, pd.DataFrame({"": [""] * max(len(a), len(b))}), b],
                       axis=1)
    collected[tag] = (df, title, desc)
    print(f"  {tag}  {len(df):5d} rows x {len(df.columns):3d} cols   {title}")

    safe = title.lower().replace(" ", "_").replace(",", "").replace("-", "_")
    df.to_csv(os.path.join(OUT, f"{tag}_{safe[:48]}.csv"), index=False)

# ── single workbook ───────────────────────────────────────────────
xlsx = os.path.join(OUT, "Supplementary_Material.xlsx")
with pd.ExcelWriter(xlsx, engine="openpyxl") as xw:
    contents = pd.DataFrame(
        [{"Table": t, "Title": v[1], "Contents": v[2],
          "Rows": len(v[0]), "Columns": len(v[0].columns)}
         for t, v in collected.items()])
    contents.to_excel(xw, sheet_name="Contents", index=False)
    for tag, (df, title, desc) in collected.items():
        df.to_excel(xw, sheet_name=tag, index=False)

# ── formatting ────────────────────────────────────────────────────
if HAVE_OPENPYXL:
    from openpyxl import load_workbook
    wb = load_workbook(xlsx)
    HEAD = Font(name="Arial", size=10, bold=True, color="FFFFFF")
    BODY = Font(name="Arial", size=10)
    FILL = PatternFill("solid", fgColor="2A6FB5")

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for c in ws[1]:
            c.font = HEAD
            c.fill = FILL
            c.alignment = Alignment(vertical="center", wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.font = BODY
                if isinstance(c.value, float):
                    c.number_format = "0.000"
        for col in ws.columns:
            letter = get_column_letter(col[0].column)
            width = max((len(str(c.value)) for c in col if c.value is not None),
                        default=10)
            ws.column_dimensions[letter].width = min(max(width + 2, 11), 46)
        ws.row_dimensions[1].height = 28

    ws = wb["Contents"]
    ws.column_dimensions["C"].width = 78
    for r in range(2, ws.max_row + 1):
        ws.cell(r, 3).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = 46
    wb.save(xlsx)
    print("\nworkbook formatted (Arial, frozen headers, sized columns)")

# ── README ────────────────────────────────────────────────────────
with open(os.path.join(OUT, "README.txt"), "w", encoding="utf-8") as f:
    f.write("SUPPLEMENTARY MATERIAL\n")
    f.write("Cohort composition confounds the evaluation of interictal iEEG\n")
    f.write("biomarkers for epilepsy surgery\n")
    f.write("Anurag Tiwari, South Asian University, New Delhi\n\n")
    f.write("Supplementary_Material.xlsx contains all tables in one workbook,\n")
    f.write("with a Contents sheet. The same tables are also provided as\n")
    f.write("individual CSV files.\n\n")
    for tag, (df, title, desc) in collected.items():
        f.write(f"Supplementary Table {tag[1:]}: {title}\n")
        f.write(f"  {desc}\n")
        f.write(f"  {len(df)} rows, {len(df.columns)} columns\n\n")
    f.write("All analyses are described in the Methods section of the "
            "manuscript.\n")

print(f"\nwritten to {OUT}")
for fn in sorted(os.listdir(OUT)):
    size = os.path.getsize(os.path.join(OUT, fn)) / 1024
    print(f"  {fn:58s} {size:7.1f} KB")

if missing:
    print("\nNOT FOUND — run the corresponding analysis script first:")
    for m in missing:
        print("  " + m)
