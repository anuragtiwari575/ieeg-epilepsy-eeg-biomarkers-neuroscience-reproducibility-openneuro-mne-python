"""
FIX 1. Figure 1 and Section 3.2 were computed on a 57-participant HUP cohort;
       the final cohort has 55.

Figure 1 reports 20 ECoG + 37 SEEG = 57 and 29 resection + 28 ablation = 57.
Table 1 reports 20/35 = 55 and 29/26 = 55. The Simpson's-paradox numbers are
therefore from an earlier cohort than the rest of the paper.

This recomputes every number in Figure 1 and Section 3.2 from cohort.csv, prints
the replacement text and the corrected figure, and regenerates FIG1.
"""
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy import stats

BASE = os.environ.get("IEEG_BASE", r"C:\Users\Anurag Tiwari\ieeg_project")
R = os.path.join(BASE, "results")

coh = pd.read_csv(os.path.join(R, "cohort.csv"))
u = coh[coh.usable].copy()
hup = u[u.dataset == "ds004100"]
oth = u[u.dataset == "ds003876"]

print("=" * 74)
print("COHORT AS ACTUALLY ANALYSED")
print("=" * 74)
print(f"total usable            : {len(u)}")
print(f"  ds004100 (HUP)        : {len(hup)}")
print(f"  ds003876              : {len(oth)}")
print(f"\nHUP implant   ECoG/SEEG : {(hup.implant=='ECOG').sum()} / "
      f"{(hup.implant=='SEEG').sum()}")
print(f"HUP therapy   res/abl   : {(hup.therapy=='RESECTION').sum()} / "
      f"{(hup.therapy=='ABLATION').sum()}")


def mw(a, b, la, lb):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 3 or len(b) < 3:
        return dict(n1=len(a), n2=len(b), m1=np.nan, m2=np.nan, p=np.nan)
    U, p = stats.mannwhitneyu(a, b)
    return dict(n1=len(a), n2=len(b), m1=100 * np.median(a),
                m2=100 * np.median(b), U=U, p=p, la=la, lb=lb)


print("\n" + "=" * 74)
print("SIMPSON'S PARADOX, RECOMPUTED ON THE FINAL HUP COHORT")
print("=" * 74)

pv = hup.prevalence
A = mw(pv[hup.implant == "ECOG"], pv[hup.implant == "SEEG"], "ECoG", "SEEG")
B = mw(pv[hup.therapy == "RESECTION"], pv[hup.therapy == "ABLATION"],
       "Resection", "Ablation")
res = hup[hup.therapy == "RESECTION"]
rp = res.prevalence
C = mw(rp[res.implant == "ECOG"], rp[res.implant == "SEEG"], "ECoG", "SEEG")

for tag, d in [("A  marginal, by implant", A),
               ("B  by therapy", B),
               ("C  implant within resection", C)]:
    print(f"\n{tag}")
    print(f"   {d['la']:<12}{d['m1']:6.1f}%   n = {d['n1']}")
    print(f"   {d['lb']:<12}{d['m2']:6.1f}%   n = {d['n2']}")
    print(f"   p = {d['p']:.4g}")

# collinearity, quoted in the text
ec = hup[hup.implant == "ECOG"]
se = hup[hup.implant == "SEEG"]
print(f"\ncollinearity: {(ec.therapy=='RESECTION').sum()} of {len(ec)} ECoG had "
      f"resection; {(se.therapy=='ABLATION').sum()} of {len(se)} SEEG had ablation")

# ── the other release, for Section 3.3 ────────────────────────────
po = oth.prevalence
D = mw(po[oth.implant == "ECOG"], po[oth.implant == "SEEG"], "ECoG", "SEEG")
print(f"\nds003876 implant: ECoG {D['m1']:.1f}% (n={D['n1']}) vs "
      f"SEEG {D['m2']:.1f}% (n={D['n2']}), p = {D['p']:.4g}")

pu = u.prevalence
E = mw(pu[u.implant == "ECOG"], pu[u.implant == "SEEG"], "ECoG", "SEEG")
print(f"pooled implant  : ECoG {E['m1']:.1f}% (n={E['n1']}) vs "
      f"SEEG {E['m2']:.1f}% (n={E['n2']}), p = {E['p']:.4g}")

# lesional / target, quoted in 3.3
for var in ["lesion_status", "target"]:
    try:
        p4 = pd.read_csv(os.path.join(BASE, "raw", "ds004100",
                                      "participants.tsv"), sep="\t")
        p4.columns = [c.strip() for c in p4.columns]
        p4["sub"] = p4[p4.columns[0]].astype(str).str.strip()
        m = hup.merge(p4[["sub", var]], on="sub", how="left").dropna(subset=[var])
        g = m.groupby(var)["prevalence"].agg(
            n="count", median=lambda x: round(100 * x.median(), 1))
        print(f"\nprevalence by {var}:")
        print(g.to_string())
    except Exception as e:
        print(f"  {var}: {e}")

# ── replacement text ──────────────────────────────────────────────
print("\n" + "=" * 74)
print("REPLACEMENT TEXT FOR SECTION 3.2")
print("=" * 74)
print(f"""
In \\code{{ds004100}}, treated-channel prevalence differed by electrode modality:
median {A['m1']:.1f}\\% for ECoG ($n = {A['n1']}$) versus {A['m2']:.1f}\\% for
SEEG ($n = {A['n2']}$), $p = {A['p']:.3f}$ (Fig.~1A).

Stratification by treatment modality removed the effect. Among resection
participants, ECoG gave {C['m1']:.1f}\\% ($n = {C['n1']}$) and SEEG
{C['m2']:.1f}\\% ($n = {C['n2']}$), $p = {C['p']:.3f}$ (Fig.~1C). The determining
variable was therapy: resection {B['m1']:.1f}\\% ($n = {B['n1']}$) versus
ablation {B['m2']:.1f}\\% ($n = {B['n2']}$), $p = {B['p']:.2g}$ (Fig.~1B), a
{B['m1']/B['m2']:.1f}-fold difference in the positive-class rate.

The marginal association arises because the variables are collinear:
{(ec.therapy=='RESECTION').sum()} of {len(ec)} ECoG participants received
resection whereas {(se.therapy=='ABLATION').sum()} of {len(se)} SEEG
participants received ablation.
""")

# ── regenerate Figure 1 ───────────────────────────────────────────
mpl.rcParams.update({"font.size": 8, "font.family": "serif",
                     "axes.linewidth": 0.7, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.bbox": "tight",
                     "savefig.dpi": 300, "xtick.labelsize": 7.5,
                     "ytick.labelsize": 7.5})
BLUE, ORNG, GREEN, GRID = "#2a6fb5", "#e07b39", "#1a9e6e", "#e3e3dd"


def pfmt(p):
    if p < 1e-4:
        e = int(np.floor(np.log10(p)))
        return f"$p$ = {p/10**e:.1f}$\\times$10$^{{{e}}}$"
    return f"$p$ = {p:.3f}"


fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.9))
panels = [
    ([f"ECoG\n(n={A['n1']})", f"SEEG\n(n={A['n2']})"], [A['m1'], A['m2']],
     [BLUE, ORNG], pfmt(A['p']), False),
    ([f"Resection\n(n={B['n1']})", f"Ablation\n(n={B['n2']})"],
     [B['m1'], B['m2']], [GREEN, GREEN], pfmt(B['p']), False),
    ([f"ECoG\n(n={C['n1']})", f"SEEG\n(n={C['n2']})"], [C['m1'], C['m2']],
     [BLUE, ORNG], pfmt(C['p']), True),
]
top = max(max(v) for _, v, _, _, _ in panels) * 1.42
for a, letter, (labels, vals, cols, ptxt, bold) in zip(ax, "ABC", panels):
    b = a.bar(labels, vals, color=cols, width=0.55, zorder=3)
    a.bar_label(b, fmt="%.1f%%", padding=3, fontsize=8)
    a.set_ylim(0, top)
    a.grid(axis="y", color=GRID, lw=0.6, zorder=0)
    a.set_axisbelow(True)
    a.text(0.5, 0.94, ptxt, transform=a.transAxes, ha="center",
           fontsize=8.5, fontweight="bold" if bold else "normal")
    a.text(-0.16, 1.06, letter, transform=a.transAxes, fontsize=10,
           fontweight="bold", va="bottom", ha="left")
ax[0].set_ylabel("median treated-channel\nprevalence (%)")
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(R, f"FIG1_simpsons_paradox.{ext}"))
plt.close(fig)
print("Figure 1 regenerated from the final cohort")

SUB = os.path.join(BASE, "submission")
if os.path.isdir(SUB):
    import shutil
    shutil.copy(os.path.join(R, "FIG1_simpsons_paradox.pdf"),
                os.path.join(SUB, "FIG1_simpsons_paradox.pdf"))
    print("staged into submission/")
