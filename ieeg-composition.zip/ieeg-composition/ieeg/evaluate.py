"""Metrics, negative controls, and the cohort-composition analysis.

Design rules enforced here:
  * AUPRC is computed PER PATIENT and averaged; channels are never pooled.
  * lift = AUPRC / prevalence, so the null is 1 regardless of prevalence.
  * every headline number is accompanied by a permutation control.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score

from . import config as C


# ------------------------------------------------------------------ metrics
def empirical_null_ap(y: np.ndarray, n_perm: int = 200, seed: int = C.RANDOM_SEED) -> float:
    """Mean AUPRC under random ranking for THIS patient's label vector.

    The theoretical null for average precision is the prevalence pi, but that
    identity is asymptotic. At small positive counts - exactly the low-prevalence
    patients this project cares about - AP under random ranking is biased ABOVE
    pi, so AUPRC/pi does not have null 1. Smoke-testing showed values near 1.7
    at n=40, n_pos=2. We therefore normalise by the empirical null instead.
    """
    y = np.asarray(y).astype(bool)
    if y.sum() < 1 or y.all():
        return np.nan
    rng = np.random.default_rng(seed)
    return float(np.mean([average_precision_score(y, rng.random(len(y)))
                          for _ in range(n_perm)]))


def patient_metrics(score: np.ndarray, y: np.ndarray,
                    null_ap: float | None = None) -> dict:
    """Localization metrics for one patient. Higher score = more epileptogenic.

    lift      = AUPRC / prevalence          (reported for comparability)
    lift_emp  = AUPRC / empirical null      (PRIMARY - null is 1 by construction)
    """
    y = np.asarray(y).astype(bool)
    s = np.asarray(score, dtype=float)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    n, npos = len(y), int(y.sum())
    if npos < C.MIN_POSITIVE or npos == n:
        return {k: np.nan for k in
                ("auprc", "lift", "lift_emp", "norm_rank",
                 "precision_at_k", "prevalence", "null_ap")}

    prev = npos / n
    auprc = average_precision_score(y, s)
    if null_ap is None:
        null_ap = empirical_null_ap(y)
    ranks = stats.rankdata(-s)                     # rank 1 = highest score
    k = max(1, int(round(C.TOP_K_FRAC * n)))
    return {
        "auprc": auprc,
        "lift": auprc / prev,
        "lift_emp": auprc / null_ap if null_ap and null_ap > 0 else np.nan,
        "norm_rank": 1.0 - ranks[y].mean() / n,    # higher = better
        "precision_at_k": y[np.argsort(-s)][:k].mean(),
        "prevalence": prev,
        "null_ap": null_ap,
    }


def _orient(score, y):
    """Flip sign if the feature is inversely related, decided per patient.

    Orientation is a property of the feature, not of the labels, so it is
    resolved globally in evaluate_feature() - never per patient, which would
    leak label information.
    """
    return score


def evaluate_feature(rows: list[dict], feature: str) -> pd.DataFrame:
    """rows: [{'sub','dataset','score':array,'y':array}, ...] for one feature."""
    # Global orientation: use the sign of the pooled point-biserial correlation.
    allx = np.concatenate([r["score"] for r in rows])
    ally = np.concatenate([r["y"] for r in rows]).astype(float)
    ok = np.isfinite(allx)
    sign = 1.0
    if ok.sum() > 10 and len(np.unique(ally[ok])) > 1:
        r, _ = stats.pointbiserialr(ally[ok], allx[ok])
        sign = -1.0 if r < 0 else 1.0

    out = []
    for r in rows:
        null = r.get("null_ap") or empirical_null_ap(r["y"])
        r["null_ap"] = null                       # cache for later features
        m = patient_metrics(sign * r["score"], r["y"], null_ap=null)
        m.update(sub=r["sub"], dataset=r["dataset"], feature=feature, sign=sign)
        out.append(m)
    return pd.DataFrame(out)


# ------------------------------------------------------------------ controls
def permutation_control(rows: list[dict], feature: str,
                        n_perm: int = C.N_PERMUTATIONS, seed: int = C.RANDOM_SEED):
    """Shuffle labels within each patient. Mean lift must collapse to ~1."""
    rng = np.random.default_rng(seed)
    means = []
    for _ in range(n_perm):
        vals = []
        for r in rows:
            y = rng.permutation(r["y"])
            vals.append(patient_metrics(r["score"], y,
                                        null_ap=r.get("null_ap"))["lift_emp"])
        means.append(np.nanmean(vals))
    means = np.asarray(means)
    return {"feature": feature, "perm_mean_lift": float(np.nanmean(means)),
            "perm_sd": float(np.nanstd(means)),
            "perm_ci_lo": float(np.nanpercentile(means, 2.5)),
            "perm_ci_hi": float(np.nanpercentile(means, 97.5))}


def random_baseline(rows: list[dict], seed: int = C.RANDOM_SEED):
    rng = np.random.default_rng(seed)
    vals = [patient_metrics(rng.random(len(r["y"])), r["y"],
                            null_ap=r.get("null_ap"))["lift_emp"] for r in rows]
    return {"feature": "RANDOM", "mean_lift": float(np.nanmean(vals)),
            "sd": float(np.nanstd(vals))}


# ------------------------------------------------------------------ confound
def confound_analysis(coh: pd.DataFrame) -> dict:
    """Reproduces the Simpson's-paradox result: the marginal implant effect and
    its collapse once therapy is conditioned on."""
    u = coh[coh["usable"] & coh["prevalence"].notna()].copy()
    res = {}

    def mw(a, b):
        a, b = np.asarray(a, float), np.asarray(b, float)
        if len(a) < 3 or len(b) < 3:
            return dict(n1=len(a), n2=len(b), med1=np.nanmedian(a),
                        med2=np.nanmedian(b), p=np.nan)
        s, p = stats.mannwhitneyu(a, b)
        return dict(n1=len(a), n2=len(b), med1=float(np.nanmedian(a)),
                    med2=float(np.nanmedian(b)), U=float(s), p=float(p))

    pv = u["prevalence"] * 100

    res["therapy"] = mw(pv[u.therapy == "RESECTION"], pv[u.therapy == "ABLATION"])
    res["implant_marginal"] = mw(pv[u.implant == "ECOG"], pv[u.implant == "SEEG"])

    r = u[u.therapy == "RESECTION"]
    rpv = r["prevalence"] * 100
    res["implant_within_resection"] = mw(rpv[r.implant == "ECOG"],
                                         rpv[r.implant == "SEEG"])

    res["table_2x2"] = (u.groupby(["implant", "therapy"])["prevalence"]
                        .agg(n="count", median=lambda x: 100 * x.median())
                        .reset_index())
    res["by_dataset"] = (u.groupby("dataset")["prevalence"]
                         .agg(n="count", median=lambda x: 100 * x.median(),
                              lo=lambda x: 100 * x.min(), hi=lambda x: 100 * x.max())
                         .reset_index())
    return res


def partial_corr(x, y, covars: pd.DataFrame):
    """Partial Pearson correlation of x and y controlling for covars."""
    df = pd.concat([pd.Series(x, name="x"), pd.Series(y, name="y"),
                    covars.reset_index(drop=True)], axis=1).dropna()
    if len(df) < 8:
        return np.nan, np.nan
    Z = np.column_stack([np.ones(len(df)), df[covars.columns].to_numpy(float)])
    rx = df["x"] - Z @ np.linalg.lstsq(Z, df["x"], rcond=None)[0]
    ry = df["y"] - Z @ np.linalg.lstsq(Z, df["y"], rcond=None)[0]
    return stats.pearsonr(rx, ry)


def composition_sensitivity(perf: pd.DataFrame, coh: pd.DataFrame) -> pd.DataFrame:
    """Does performance track prevalence rather than epileptogenicity?

    Reports, per feature: raw correlation of AUPRC with prevalence (the naive
    baseline), and the partial correlation of lift with outcome controlling for
    prevalence, therapy and implant.
    """
    meta = coh.set_index("sub")[["therapy", "implant", "seizure_free"]]
    out = []
    for feat, g in perf.groupby("feature"):
        g = g.dropna(subset=["auprc", "prevalence"]).join(meta, on="sub")
        if len(g) < 8:
            continue
        r_prev, p_prev = stats.pearsonr(g["auprc"], g["prevalence"])
        cov = pd.DataFrame({
            "prevalence": g["prevalence"].to_numpy(),
            "is_resection": (g["therapy"] == "RESECTION").astype(float).to_numpy(),
            "is_ecog": (g["implant"] == "ECOG").astype(float).to_numpy(),
        })
        r_out, p_out = partial_corr(g["lift_emp"].to_numpy(),
                                    g["seizure_free"].astype(float).to_numpy(), cov)
        out.append({"feature": feat, "n": len(g),
                    "mean_auprc": g["auprc"].mean(), "mean_lift": g["lift_emp"].mean(),
                    "corr_auprc_prevalence": r_prev, "p_prev": p_prev,
                    "partial_corr_lift_outcome": r_out, "p_outcome": p_out})
    return pd.DataFrame(out).sort_values("mean_lift", ascending=False)


def outcome_stratified(perf: pd.DataFrame, coh: pd.DataFrame) -> pd.DataFrame:
    """Agreement in seizure-free vs not. Expected: HIGH vs LOW (pre-declared)."""
    meta = coh.set_index("sub")[["seizure_free", "therapy", "implant"]]
    out = []
    for feat, g in perf.groupby("feature"):
        g = g.dropna(subset=["lift_emp"]).join(meta, on="sub")
        a = g.loc[g.seizure_free == True, "lift_emp"]
        b = g.loc[g.seizure_free == False, "lift_emp"]
        if len(a) < 3 or len(b) < 3:
            continue
        s, p = stats.mannwhitneyu(a, b)
        # rank-biserial effect size
        rb = 1 - 2 * s / (len(a) * len(b))
        out.append({"feature": feat, "n_free": len(a), "n_poor": len(b),
                    "lift_free": a.median(), "lift_poor": b.median(),
                    "diff": a.median() - b.median(), "p": p,
                    "rank_biserial": -rb,
                    "direction_ok": a.median() > b.median()})
    return pd.DataFrame(out).sort_values("p")


def ranking_comparison(perf: pd.DataFrame, coh: pd.DataFrame) -> pd.DataFrame:
    """Naive ranking (pooled mean AUPRC) vs corrected (therapy-stratified lift)."""
    naive = perf.groupby("feature")["auprc"].mean().rank(ascending=False)
    meta = coh.set_index("sub")["therapy"]
    p = perf.join(meta, on="sub")
    strat = (p.groupby(["feature", "therapy"])["lift_emp"].mean()
             .groupby("feature").mean().rank(ascending=False))
    df = pd.DataFrame({"rank_naive": naive, "rank_corrected": strat})
    df["shift"] = df["rank_naive"] - df["rank_corrected"]
    return df.sort_values("rank_corrected")
