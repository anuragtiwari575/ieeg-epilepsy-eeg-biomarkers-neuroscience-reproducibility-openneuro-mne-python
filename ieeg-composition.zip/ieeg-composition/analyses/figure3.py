"""
Regenerate Figure 3 with corrected axis labels.

In the 79-participant re-analysis the positive class is the clinically annotated
epileptogenic zone distributed with the derivative files, NOT the treated volume
used in the main cohort. The axis labels must say so, otherwise the figure
contradicts the caption and the Methods.

Writes FIG3_reference_validation.{png,pdf} into results/.
Run this, then copy the PDF into submission/.
"""
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")

mpl.rcParams.update({
    "font.size": 8, "font.family": "serif", "axes.linewidth": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.dpi": 300,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 6.4,
})
BLUE, ORNG, GREEN, RED, GREY = "#2a6fb5", "#e07b39", "#1a9e6e", "#c33", "#7a7a7a"
GREEN_DK, GRID = "#0f6e56", "#e3e3dd"

XLAB = "annotated-zone prevalence"          # <-- corrected


def panel(ax, letter):
    ax.text(-0.16, 1.06, letter, transform=ax.transAxes,
            fontsize=10, fontweight="bold", va="bottom", ha="left")


r = pd.read_csv(os.path.join(R, "reference_ssi_validation.csv"))
rng = np.random.default_rng(0)

fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.9))

# ── A. average precision vs prevalence ────────────────────────────
ax[0].scatter(r.prev, r.auprc, s=18, alpha=.75, color=BLUE,
              edgecolor="white", linewidth=.4, zorder=3)
xs = np.linspace(r.prev.min(), r.prev.max(), 50)
ax[0].plot(xs, xs, ls=":", color=RED, lw=1.3, zorder=2,
           label="theoretical random-ranking\nreference "
                 r"($\mathrm{AP} = \pi$)")
ax[0].set_xlabel(XLAB)
ax[0].set_ylabel("average precision")
ax[0].legend(frameon=False, loc="upper left", handlelength=1.4)
ax[0].text(.97, .05, "$r$ = 0.43\n$p$ = 9.5$\\times$10$^{-5}$",
           transform=ax[0].transAxes, ha="right", va="bottom", fontsize=7)

# ── B. normalised lift vs prevalence ──────────────────────────────
below = r.lift_emp < 1
ax[1].scatter(r.prev[~below], r.lift_emp[~below], s=18, alpha=.75, color=ORNG,
              edgecolor="white", linewidth=.4, zorder=3)
ax[1].scatter(r.prev[below], r.lift_emp[below], s=18, alpha=.85, color=RED,
              edgecolor="white", linewidth=.4, zorder=3,
              label=f"below empirical null ({int(below.sum())}/{len(r)})")
ax[1].axhline(1, ls="--", color=GREY, lw=1.0, zorder=2)
ax[1].set_ylim(0, 11.5)
ax[1].set_xlabel(XLAB)
ax[1].set_ylabel(r"normalised lift $\lambda = \mathrm{AP}/\mathrm{AP}_0$")
ax[1].legend(frameon=False, loc="upper right", handlelength=1.0)
ax[1].text(.97, .62, "$r$ = $-$0.06\n$p$ = 0.60", transform=ax[1].transAxes,
           ha="right", va="top", fontsize=7)

# ── C. lift stratified by annotated-zone size ─────────────────────
lo = r.loc[r.prev < 0.06, "lift_emp"]
hi = r.loc[r.prev >= 0.06, "lift_emp"]
labs = [f"< 6%\n(n={len(lo)})", f"$\\geq$ 6%\n(n={len(hi)})"]
try:
    bp = ax[2].boxplot([lo, hi], widths=.5, showfliers=False,
                       patch_artist=True, zorder=3, tick_labels=labs)
except TypeError:                       # matplotlib < 3.9
    bp = ax[2].boxplot([lo, hi], widths=.5, showfliers=False,
                       patch_artist=True, zorder=3, labels=labs)
for box, c in zip(bp["boxes"], [RED, GREEN]):
    box.set_facecolor(c); box.set_alpha(.25); box.set_edgecolor(c)
for el in ("whiskers", "caps", "medians"):
    for ln in bp[el]:
        ln.set_color("#444"); ln.set_linewidth(1.0)
for i, d in enumerate([lo, hi]):
    ax[2].scatter(rng.normal(i + 1, .06, len(d)), d, s=12, alpha=.65,
                  color=[RED, GREEN][i], zorder=4)
ax[2].axhline(1, ls="--", color=GREY, lw=1.0, zorder=2)
ax[2].set_ylim(0, 13.2)
ax[2].set_xlabel(XLAB)
ax[2].set_ylabel(r"normalised lift $\lambda$")
ax[2].text(1, 11.4, "55% below null", ha="center", fontsize=6.8, color=RED)
ax[2].text(2, 11.4, "26% below null", ha="center", fontsize=6.8, color=GREEN_DK)
ax[2].text(1.5, 12.6, "OR = 3.4, $p$ = 0.018", ha="center", fontsize=7)

for a, letter in zip(ax, "ABC"):
    a.grid(color=GRID, lw=.5, zorder=0)
    a.set_axisbelow(True)
    panel(a, letter)

fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(R, f"FIG3_reference_validation.{ext}"))
plt.close(fig)
print("saved: FIG3_reference_validation  (axis labels now read "
      f"'{XLAB}')")

# ── stage into submission/ ────────────────────────────────────────
SUB = os.path.join(BASE, "submission")
if os.path.isdir(SUB):
    import shutil
    shutil.copy(os.path.join(R, "FIG3_reference_validation.pdf"),
                os.path.join(SUB, "FIG3_reference_validation.pdf"))
    print("copied into submission/")
else:
    print("submission/ not found - copy the PDF across manually")
