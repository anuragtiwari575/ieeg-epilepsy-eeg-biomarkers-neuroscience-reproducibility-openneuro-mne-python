"""Submission-readiness pass on Figures 1, 3 and 4.

Journals carry the description in the caption, not in the image. Baked-in
titles duplicate the caption and get flagged in copy-editing. Panel letters,
by contrast, must be IN the image because the caption refers to them.

  Fig 1  remove suptitle, add A/B/C
  Fig 3  remove suptitle, add A/B/C, rename to FIG3_reference_validation
  Fig 4  remove suptitle (panels are labelled by feature name)
"""
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy import stats

BASE = r"C:\Users\Anurag Tiwari\ieeg_project"
R = os.path.join(BASE, "results")

mpl.rcParams.update({
    "font.size": 8, "font.family": "serif", "axes.linewidth": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.dpi": 300,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7,
})
BLUE, ORNG, GREEN, RED, GREY = "#2a6fb5", "#e07b39", "#1a9e6e", "#c33", "#7a7a7a"
GRID = "#e3e3dd"


def panel(ax, letter):
    ax.text(-0.16, 1.06, letter, transform=ax.transAxes,
            fontsize=10, fontweight="bold", va="bottom", ha="left")


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(R, f"{name}.{ext}"))
    print("saved:", name)


# ═══════════════════════════ FIGURE 1 ═══════════════════════════
fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.9))
panels = [
    (["ECoG\n(n=20)", "SEEG\n(n=37)"], [12.8, 8.0], [BLUE, ORNG],
     "$p$ = 0.011", False),
    (["Resection\n(n=29)", "Ablation\n(n=28)"], [13.5, 5.2], [GREEN, GREEN],
     "$p$ = 3.7$\\times$10$^{-5}$", False),
    (["ECoG\n(n=18)", "SEEG\n(n=11)"], [13.6, 13.5], [BLUE, ORNG],
     "$p$ = 0.458", True),
]
for a, letter, (labels, vals, cols, ptxt, bold) in zip(ax, "ABC", panels):
    b = a.bar(labels, vals, color=cols, width=0.55, zorder=3)
    a.bar_label(b, fmt="%.1f%%", padding=3, fontsize=8)
    a.set_ylim(0, 18.5)
    a.grid(axis="y", color=GRID, lw=0.6, zorder=0)
    a.set_axisbelow(True)
    a.text(0.5, 0.94, ptxt, transform=a.transAxes, ha="center",
           fontsize=8.5, fontweight="bold" if bold else "normal")
    panel(a, letter)
ax[0].set_ylabel("median treated-channel\nprevalence (%)")
fig.tight_layout()
save(fig, "FIG1_simpsons_paradox")
plt.close(fig)


# ═══════════════════════════ FIGURE 3 ═══════════════════════════
r = pd.read_csv(os.path.join(R, "reference_ssi_validation.csv"))
fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.9))

ax[0].scatter(r.prev, r.auprc, s=18, alpha=.75, color=BLUE,
              edgecolor="white", linewidth=.4, zorder=3)
xs = np.linspace(r.prev.min(), r.prev.max(), 50)
ax[0].plot(xs, xs, ls=":", color=RED, lw=1.3, zorder=2,
           label=r"chance ($\mathrm{AP} = \pi$)")
ax[0].set_xlabel("prevalence"); ax[0].set_ylabel("average precision")
ax[0].legend(fontsize=6.6, frameon=False, loc="upper left")
ax[0].text(0.97, 0.05, "$r$ = 0.43\n$p$ = 9.5$\\times$10$^{-5}$",
           transform=ax[0].transAxes, ha="right", va="bottom", fontsize=7)

below = r.lift_emp < 1
ax[1].scatter(r.prev[~below], r.lift_emp[~below], s=18, alpha=.75, color=ORNG,
              edgecolor="white", linewidth=.4, zorder=3)
ax[1].scatter(r.prev[below], r.lift_emp[below], s=18, alpha=.85, color=RED,
              edgecolor="white", linewidth=.4, zorder=3,
              label=f"below chance ({int(below.sum())}/{len(r)})")
ax[1].axhline(1, ls="--", color=GREY, lw=1.0, zorder=2)
ax[1].set_ylim(0, 11.5)
ax[1].set_xlabel("prevalence")
ax[1].set_ylabel(r"normalised lift $\lambda$")
ax[1].legend(fontsize=6.6, frameon=False, loc="upper right")
ax[1].text(0.97, 0.62, "$r$ = $-$0.06\n$p$ = 0.60", transform=ax[1].transAxes,
           ha="right", va="top", fontsize=7)

lo = r.loc[r.prev < 0.06, "lift_emp"]
hi = r.loc[r.prev >= 0.06, "lift_emp"]
try:
    bp = ax[2].boxplot([lo, hi], widths=.5, showfliers=False, patch_artist=True,
                       zorder=3, tick_labels=[f"< 6%\n(n={len(lo)})",
                                              f"$\\geq$ 6%\n(n={len(hi)})"])
except TypeError:
    bp = ax[2].boxplot([lo, hi], widths=.5, showfliers=False, patch_artist=True,
                       zorder=3, labels=[f"< 6%\n(n={len(lo)})",
                                         f"$\\geq$ 6%\n(n={len(hi)})"])
for box, c in zip(bp["boxes"], [RED, GREEN]):
    box.set_facecolor(c); box.set_alpha(.25); box.set_edgecolor(c)
for el in ("whiskers", "caps", "medians"):
    for ln in bp[el]:
        ln.set_color("#444"); ln.set_linewidth(1.0)
rng = np.random.default_rng(0)
for i, d in enumerate([lo, hi]):
    ax[2].scatter(rng.normal(i + 1, .06, len(d)), d, s=12, alpha=.65,
                  color=[RED, GREEN][i], zorder=4)
ax[2].axhline(1, ls="--", color=GREY, lw=1.0, zorder=2)
ax[2].set_ylim(0, 11.5)
ax[2].set_xlabel("treated-channel prevalence")
ax[2].set_ylabel(r"normalised lift $\lambda$")
ax[2].text(1, 10.6, "55% below", ha="center", fontsize=7, color=RED)
ax[2].text(2, 10.6, "26% below", ha="center", fontsize=7, color="#0f6e56")
ax[2].text(0.5, 0.02, "OR = 3.4, $p$ = 0.018", transform=ax[2].transAxes,
           ha="center", va="bottom", fontsize=7)

for a, letter in zip(ax, "ABC"):
    a.grid(color=GRID, lw=0.5, zorder=0); a.set_axisbelow(True)
    panel(a, letter)
fig.tight_layout()
save(fig, "FIG3_reference_validation")
plt.close(fig)

for ext in ("png", "pdf"):
    old = os.path.join(R, f"FIG2_reference_validation.{ext}")
    if os.path.exists(old):
        os.remove(old)
print("removed old FIG2_reference_validation (renamed to FIG3)")


# ═══════════════════════════ FIGURE 4 ═══════════════════════════
perf = pd.read_csv(os.path.join(R, "per_patient_metrics.csv"))
coh = pd.read_csv(os.path.join(R, "cohort.csv"))
P = perf.join(coh.set_index("sub")[["seizure_free", "therapy"]], on="sub")
Pr = P[P.therapy == "RESECTION"]

show = [f for f in ["ssi::ssi", "fragility::fragility", "spectral::rel_theta",
                    "graph::eigencentrality"] if f in Pr.feature.unique()]
lab = {"ssi::ssi": "source-sink index", "fragility::fragility": "neural fragility",
       "spectral::rel_theta": "relative theta power",
       "graph::eigencentrality": "eigenvector centrality"}

fig, axes = plt.subplots(1, len(show), figsize=(7.1, 2.8), sharey=True)
rng = np.random.default_rng(0)
for ax_, f, letter in zip(np.atleast_1d(axes), show, "ABCD"):
    g = Pr[Pr.feature == f].dropna(subset=["lift_emp"])
    a = g.loc[g.seizure_free == True, "lift_emp"]
    b = g.loc[g.seizure_free == False, "lift_emp"]
    s, pv = stats.mannwhitneyu(a, b)
    bp = ax_.boxplot([a, b], widths=.55, showfliers=False, patch_artist=True,
                     zorder=3)
    for box, col in zip(bp["boxes"], [GREEN, ORNG]):
        box.set_facecolor(col); box.set_alpha(.25); box.set_edgecolor(col)
    for el in ("whiskers", "caps", "medians"):
        for ln in bp[el]:
            ln.set_color("#444"); ln.set_linewidth(1.0)
    for i, d in enumerate([a, b]):
        ax_.scatter(rng.normal(i + 1, .07, len(d)), d, s=11, alpha=.65,
                    color=[GREEN, ORNG][i], zorder=4)
    ax_.axhline(1, ls="--", color=GREY, lw=1.0, zorder=2)
    ax_.set_xticks([1, 2])
    ax_.set_xticklabels([f"Engel I\n(n={len(a)})", f"Engel II–IV\n(n={len(b)})"],
                        fontsize=7)
    ax_.set_title(f"{lab.get(f, f)}\n$p$ = {pv:.2f}", fontsize=7.8)
    ax_.grid(axis="y", color=GRID, lw=0.5, zorder=0); ax_.set_axisbelow(True)
    panel(ax_, letter)
np.atleast_1d(axes)[0].set_ylabel(r"normalised lift $\lambda$")
fig.tight_layout()
save(fig, "FIG4_outcome_stratified")
plt.close(fig)

print("\nSubmission figure set:")
for n in ["FIG1_simpsons_paradox", "FIG2_composition_prediction",
          "FIG3_reference_validation", "FIG4_outcome_stratified",
          "FIG5_controls"]:
    ok = os.path.exists(os.path.join(R, n + ".pdf"))
    print("  ", "ok " if ok else "MISSING", n)
