"""Configuration for the interictal iEEG biomarker pipeline."""
from pathlib import Path

# ---------------------------------------------------------------- paths
# On Colab set BASE to your Drive project folder.
import os
BASE = Path(os.environ.get("IEEG_BASE", "/content/drive/MyDrive/ieeg_project"))
RAW = BASE / "raw"
FEATURES = BASE / "features"      # per-patient checkpoints
RESULTS = BASE / "results"        # tables + figures

DATASETS = {
    "ds003876": RAW / "ds003876",   # multicentre interictal
    "ds004100": RAW / "ds004100",   # HUP
    "ds003844": RAW / "ds003844",   # RESPect intraoperative
}

# ---------------------------------------------------------------- preprocessing
LINE_FREQ = {"ds003876": 60.0, "ds004100": 60.0, "ds003844": 50.0}
BANDPASS = (0.5, 150.0)
TARGET_SFREQ = 500.0
WINDOW_SEC = 10.0
MAX_WINDOWS = 30                  # cap per patient (runtime control)

# Scalp EEG / EKG channels present in HUP recordings - not iEEG.
SCALP_PATTERN = (
    r"^(C3|C4|CZ|FZ|PZ|F[3-8]|FP[12]|T[3-6]|O[12]|P[3-4]|"
    r"A[12]|EKG\d*|ECG\d*|EEG\d*|ROC|LOC|CHIN|EMG\d*|DC\d+|TRIG.*|MARK.*|EVENT.*)$"
)

# ---------------------------------------------------------------- features
BANDS = {
    "delta": (1, 4), "theta": (4, 8), "alpha": (8, 13),
    "beta": (13, 30), "lowgamma": (30, 80), "highgamma": (80, 150),
}

# Source-sink index
SSI_WINDOW_SEC = 0.5
SSI_STEP_SEC = 0.25
SSI_RIDGE = 1e-4                  # adaptive search falls back from here

# Connectivity
CONN_METHOD = "corr"              # 'corr' (fast) or 'coh'

# ---------------------------------------------------------------- evaluation
TOP_K_FRAC = 0.10
N_PERMUTATIONS = 200
MIN_POSITIVE = 2                  # patients with fewer treated channels dropped
PREVALENCE_RANGE = (0.05, 0.50)   # for the restricted sensitivity analysis
RANDOM_SEED = 0

for _d in (FEATURES, RESULTS):
    pass  # created at runtime by ensure_dirs()


def ensure_dirs():
    for d in (FEATURES, RESULTS):
        d.mkdir(parents=True, exist_ok=True)
